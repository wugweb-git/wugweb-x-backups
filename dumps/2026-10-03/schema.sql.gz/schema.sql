--
-- PostgreSQL database dump
--

\restrict 7Y4HjkXZG0nT5bzIf2pDPaNBeNqEJFCrK5cs2O06QCskd1uWDnQtUzLn70PRybs

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: core; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA core;


--
-- Name: SCHEMA core; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA core IS 'Shared across all products: people, tenants (companies), their memberships and roles, sessions and the audit log.';


--
-- Name: docweb; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA docweb;


--
-- Name: SCHEMA docweb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA docweb IS 'DocWeb: documents, verifiable credentials, signing, products and warranties.';


--
-- Name: hrweb; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA hrweb;


--
-- Name: SCHEMA hrweb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA hrweb IS 'HRweb: employees, onboarding, documents, time off. Nookweb-era JSON records live in hrweb.app_data.';


--
-- Name: stayweb; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA stayweb;


--
-- Name: SCHEMA stayweb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA stayweb IS 'Stayweb: property management (rooms, bookings, guests, POS). Data is JSON records in stayweb.app_data.';


--
-- Name: current_tenant_ids(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.current_tenant_ids() RETURNS SETOF uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
  SELECT tenant_id FROM core.tenant_members
  WHERE user_id = auth.uid() AND status = 'active'
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.audit_log (
    id bigint NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    product text,
    action text NOT NULL,
    entity text,
    entity_id text,
    detail jsonb,
    ip inet
);


--
-- Name: TABLE audit_log; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.audit_log IS 'Who did what, when, in which tenant and product.';


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

ALTER TABLE core.audit_log ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME core.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: roles; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.roles (
    product text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    landing text
);


--
-- Name: TABLE roles; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.roles IS 'Roles each product offers (e.g. HRweb: HR / Employee) and which side of the product they land on.';


--
-- Name: sessions; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid,
    product text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    user_agent text,
    ip inet
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.sessions IS 'Signed-in sessions across products.';


--
-- Name: tenant_members; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.tenant_members (
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    product text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    invited_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_members_status_check CHECK ((status = ANY (ARRAY['invited'::text, 'active'::text, 'suspended'::text])))
);


--
-- Name: TABLE tenant_members; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.tenant_members IS 'Who belongs to which tenant, in which product, with which role.';


--
-- Name: tenants; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    tier text DEFAULT 'free'::text NOT NULL,
    domains text[] DEFAULT '{}'::text[] NOT NULL,
    db_location text DEFAULT 'shared'::text NOT NULL,
    db_config jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenants_db_location_check CHECK ((db_location = ANY (ARRAY['shared'::text, 'dedicated'::text]))),
    CONSTRAINT tenants_tier_check CHECK ((tier = ANY (ARRAY['free'::text, 'paid'::text])))
);


--
-- Name: TABLE tenants; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.tenants IS 'A customer company. Wugweb is tenant #1. Tier (free/paid), custom domains and where its database lives.';


--
-- Name: users; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    name text,
    phone text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE users; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.users IS 'One account per person (by email), shared by every product.';


--
-- Name: activity_logs; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.activity_logs (
    id text NOT NULL,
    user_id uuid,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    metadata text,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: analytics_events; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.analytics_events (
    id text NOT NULL,
    event_type text NOT NULL,
    user_id uuid,
    metadata text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: api_keys; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.api_keys (
    id text NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    role text DEFAULT 'read_only'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    last_used_at text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT api_keys_role_check CHECK ((role = ANY (ARRAY['full'::text, 'read_only'::text, 'certify_only'::text]))),
    CONSTRAINT api_keys_status_check CHECK ((status = ANY (ARRAY['active'::text, 'revoked'::text])))
);


--
-- Name: blockchain_proofs; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.blockchain_proofs (
    id text NOT NULL,
    transaction_id text NOT NULL,
    proof_type text NOT NULL,
    proof_data text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT blockchain_proofs_proof_type_check CHECK ((proof_type = ANY (ARRAY['merkle'::text, 'zk'::text, 'signature'::text])))
);


--
-- Name: blockchain_transactions; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.blockchain_transactions (
    id text NOT NULL,
    credential_id text,
    transaction_hash text NOT NULL,
    blockchain_network text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    gas_used integer,
    anchored_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT blockchain_transactions_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'confirmed'::text, 'failed'::text])))
);


--
-- Name: credential_attributes; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_attributes (
    id text NOT NULL,
    credential_id text NOT NULL,
    attribute_name text NOT NULL,
    attribute_value text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: credential_history; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_history (
    id text NOT NULL,
    credential_id text NOT NULL,
    event_type text NOT NULL,
    event_data text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT credential_history_event_type_check CHECK ((event_type = ANY (ARRAY['issued'::text, 'verified'::text, 'revoked'::text, 'updated'::text])))
);


--
-- Name: credential_metrics; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_metrics (
    id text NOT NULL,
    credential_id text NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    downloads integer DEFAULT 0 NOT NULL,
    shares integer DEFAULT 0 NOT NULL,
    verifications integer DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: credential_schemas; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_schemas (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    version text DEFAULT '1.0'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT credential_schemas_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'deprecated'::text])))
);


--
-- Name: credential_subjects; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_subjects (
    id text NOT NULL,
    credential_id text NOT NULL,
    subject_identifier text NOT NULL,
    subject_name text NOT NULL,
    subject_email text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: credentials; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credentials (
    id text NOT NULL,
    schema_id text NOT NULL,
    template_id text,
    issuer_id uuid NOT NULL,
    subject_id text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    blockchain_hash text,
    issued_at text,
    expires_at text,
    revoked_at text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT credentials_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'issued'::text, 'revoked'::text, 'expired'::text])))
);


--
-- Name: did_entities; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.did_entities (
    id text NOT NULL,
    did text NOT NULL,
    public_key text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT did_entities_status_check CHECK ((status = ANY (ARRAY['active'::text, 'revoked'::text])))
);


--
-- Name: did_keys; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.did_keys (
    id text NOT NULL,
    did_entity_id text NOT NULL,
    key_type text NOT NULL,
    public_key text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT did_keys_key_type_check CHECK ((key_type = ANY (ARRAY['Ed25519'::text, 'secp256k1'::text, 'RSA'::text])))
);


--
-- Name: document_audit_log; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_audit_log (
    id text NOT NULL,
    document_id text NOT NULL,
    action text NOT NULL,
    user_id uuid,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    metadata text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: document_signatures; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_signatures (
    id text NOT NULL,
    document_id text NOT NULL,
    signer_id text NOT NULL,
    signature_data text NOT NULL,
    signature_type text NOT NULL,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT document_signatures_signature_type_check CHECK ((signature_type = ANY (ARRAY['drawn'::text, 'digital'::text, 'cryptographic'::text])))
);


--
-- Name: document_signers; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_signers (
    id text NOT NULL,
    document_id text NOT NULL,
    user_id uuid,
    signer_email text,
    signer_name text,
    sign_order integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    signed_at text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT document_signers_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'signed'::text, 'rejected'::text])))
);


--
-- Name: document_versions; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_versions (
    id text NOT NULL,
    document_id text NOT NULL,
    version_number integer NOT NULL,
    file_url text NOT NULL,
    sha256_hash text,
    created_at text DEFAULT (now())::text NOT NULL,
    created_by_user_id uuid NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.documents (
    id text NOT NULL,
    created_by_user_id uuid NOT NULL,
    file_url text NOT NULL,
    title text NOT NULL,
    file_type text,
    file_size integer,
    sha256_hash text,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    updated_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT documents_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'certified'::text, 'archived'::text])))
);


--
-- Name: integration_events; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.integration_events (
    id text NOT NULL,
    integration_id text NOT NULL,
    event_type text NOT NULL,
    payload text,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT integration_events_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processed'::text, 'failed'::text])))
);


--
-- Name: integrations; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.integrations (
    id text NOT NULL,
    provider text NOT NULL,
    api_key text,
    webhook_url text,
    status text DEFAULT 'active'::text NOT NULL,
    config text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT integrations_status_check CHECK ((status = ANY (ARRAY['active'::text, 'disconnected'::text, 'error'::text])))
);


--
-- Name: invoices; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.invoices (
    id text NOT NULL,
    subscription_id text NOT NULL,
    amount real NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    issued_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT invoices_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'sent'::text, 'paid'::text, 'overdue'::text])))
);


--
-- Name: notifications; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.notifications (
    id text NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    title text,
    message text NOT NULL,
    status text DEFAULT 'unread'::text NOT NULL,
    metadata text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT notifications_status_check CHECK ((status = ANY (ARRAY['unread'::text, 'read'::text, 'dismissed'::text])))
);


--
-- Name: product_certificates; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.product_certificates (
    id text NOT NULL,
    product_id text NOT NULL,
    certificate_type text NOT NULL,
    certificate_file text,
    issued_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: product_qr_codes; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.product_qr_codes (
    id text NOT NULL,
    product_id text NOT NULL,
    qr_code_url text NOT NULL,
    verification_url text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.products (
    id text NOT NULL,
    product_name text NOT NULL,
    manufacturer text,
    batch_number text,
    manufacture_date text,
    expiry_date text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: qr_scans; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.qr_scans (
    id text NOT NULL,
    qr_code_id text NOT NULL,
    scanned_at text DEFAULT (now())::text NOT NULL,
    ip_address text,
    location text,
    device text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: schema_attributes; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.schema_attributes (
    id text NOT NULL,
    schema_id text NOT NULL,
    attribute_name text NOT NULL,
    attribute_type text NOT NULL,
    required integer DEFAULT 0 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT schema_attributes_attribute_type_check CHECK ((attribute_type = ANY (ARRAY['string'::text, 'number'::text, 'date'::text, 'boolean'::text])))
);


--
-- Name: subscription_plans; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    price real NOT NULL,
    credential_limit integer,
    api_limit integer,
    features text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.subscriptions (
    id text NOT NULL,
    plan_id text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    started_at text DEFAULT (now())::text NOT NULL,
    expires_at text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT subscriptions_status_check CHECK ((status = ANY (ARRAY['active'::text, 'past_due'::text, 'cancelled'::text])))
);


--
-- Name: system_logs; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.system_logs (
    id text NOT NULL,
    service text NOT NULL,
    level text NOT NULL,
    message text NOT NULL,
    metadata text,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT system_logs_level_check CHECK ((level = ANY (ARRAY['debug'::text, 'info'::text, 'warn'::text, 'error'::text, 'critical'::text])))
);


--
-- Name: template_elements; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.template_elements (
    id text NOT NULL,
    template_id text NOT NULL,
    element_type text NOT NULL,
    position_x real DEFAULT 0 NOT NULL,
    position_y real DEFAULT 0 NOT NULL,
    width real DEFAULT 100 NOT NULL,
    height real DEFAULT 40 NOT NULL,
    data_binding text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT template_elements_element_type_check CHECK ((element_type = ANY (ARRAY['text'::text, 'image'::text, 'QR'::text, 'table'::text, 'HTML'::text])))
);


--
-- Name: templates; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.templates (
    id text NOT NULL,
    schema_id text,
    name text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT templates_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'archived'::text])))
);


--
-- Name: tenant_settings; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.tenant_settings (
    tenant_id uuid NOT NULL,
    branding_color text,
    default_template_id text,
    default_schema_id text
);


--
-- Name: TABLE tenant_settings; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON TABLE docweb.tenant_settings IS 'Per-tenant DocWeb settings (branding colour, default template and credential schema).';


--
-- Name: verification_requests; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.verification_requests (
    id text NOT NULL,
    credential_id text,
    requester_ip text,
    verification_method text NOT NULL,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT verification_requests_verification_method_check CHECK ((verification_method = ANY (ARRAY['QR'::text, 'API'::text, 'manual'::text])))
);


--
-- Name: verification_results; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.verification_results (
    id text NOT NULL,
    verification_request_id text NOT NULL,
    status text NOT NULL,
    message text,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT verification_results_status_check CHECK ((status = ANY (ARRAY['valid'::text, 'invalid'::text, 'expired'::text, 'revoked'::text])))
);


--
-- Name: warranties; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.warranties (
    id text NOT NULL,
    product_id text NOT NULL,
    owner_id uuid,
    purchase_date text,
    registered_at text DEFAULT (now())::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT warranties_status_check CHECK ((status = ANY (ARRAY['active'::text, 'expired'::text, 'claimed'::text])))
);


--
-- Name: warranty_claims; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.warranty_claims (
    id text NOT NULL,
    warranty_id text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'submitted'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT warranty_claims_status_check CHECK ((status = ANY (ARRAY['submitted'::text, 'under_review'::text, 'approved'::text, 'rejected'::text])))
);


--
-- Name: webhook_events; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.webhook_events (
    id text NOT NULL,
    webhook_id text NOT NULL,
    event_type text NOT NULL,
    payload text NOT NULL,
    response_status integer,
    response_body text,
    delivered_at text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: webhooks; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.webhooks (
    id text NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    secret text,
    events text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT webhooks_status_check CHECK ((status = ANY (ARRAY['active'::text, 'paused'::text, 'failed'::text])))
);


--
-- Name: app_data; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.app_data (
    key text NOT NULL,
    value jsonb NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: TABLE app_data; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.app_data IS 'Nookweb-era HR records as key -> JSON (events, time off, user profiles).';


--
-- Name: document_categories_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.document_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_categories; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.document_categories (
    id integer DEFAULT nextval('hrweb.document_categories_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    description text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.documents (
    id integer DEFAULT nextval('hrweb.documents_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    filename text NOT NULL,
    filesize integer NOT NULL,
    mime_type text NOT NULL,
    category_id integer,
    uploaded_by integer NOT NULL,
    uploaded_at timestamp without time zone DEFAULT now() NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    metadata jsonb,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: employee_onboarding_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.employee_onboarding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_onboarding; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.employee_onboarding (
    id integer DEFAULT nextval('hrweb.employee_onboarding_id_seq'::regclass) NOT NULL,
    employee_id integer NOT NULL,
    step_id integer NOT NULL,
    status text DEFAULT 'not_started'::text NOT NULL,
    completed_at timestamp without time zone,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.employees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.employees (
    id integer DEFAULT nextval('hrweb.employees_id_seq'::regclass) NOT NULL,
    username text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text NOT NULL,
    company_email text,
    role text DEFAULT 'employee'::text NOT NULL,
    gender text,
    department text,
    "position" text,
    job_area text,
    avatar text,
    last_login timestamp without time zone,
    linkedin text,
    github text,
    behance text,
    dribbble text,
    twitter text,
    website text,
    pan_number text,
    aadhaar_number text,
    passport_number text,
    pf_number text,
    uan_number text,
    bank_account_number text,
    bank_name text,
    ifsc_code text,
    phone_number text,
    emergency_contact_name text,
    emergency_contact_number text,
    emergency_contact_relation text,
    current_address text,
    permanent_address text,
    city text,
    state text,
    country text,
    pincode text,
    employee_id text,
    joining_date timestamp without time zone,
    probation_end_date timestamp without time zone,
    employment_type text,
    work_location text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: TABLE employees; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.employees IS 'Employee HR profile (job, contact, statutory and bank details). Login accounts are core.users.';


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.events (
    id integer DEFAULT nextval('hrweb.events_id_seq'::regclass) NOT NULL,
    title text NOT NULL,
    description text,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    location text,
    category text,
    created_by integer NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: onboarding_steps_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.onboarding_steps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: onboarding_steps; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.onboarding_steps (
    id integer DEFAULT nextval('hrweb.onboarding_steps_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    description text,
    "order" integer NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: report_dashboards_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.report_dashboards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_dashboards; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.report_dashboards (
    id integer DEFAULT nextval('hrweb.report_dashboards_id_seq'::regclass) NOT NULL,
    employee_id integer NOT NULL,
    name text NOT NULL,
    layout jsonb NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: time_off_balances_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.time_off_balances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_off_balances; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.time_off_balances (
    id integer DEFAULT nextval('hrweb.time_off_balances_id_seq'::regclass) NOT NULL,
    employee_id integer NOT NULL,
    vacation_total integer DEFAULT 20 NOT NULL,
    vacation_used integer DEFAULT 0 NOT NULL,
    sick_total integer DEFAULT 10 NOT NULL,
    sick_used integer DEFAULT 0 NOT NULL,
    personal_total integer DEFAULT 5 NOT NULL,
    personal_used integer DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: app_data; Type: TABLE; Schema: stayweb; Owner: -
--

CREATE TABLE stayweb.app_data (
    key text NOT NULL,
    value jsonb NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: TABLE app_data; Type: COMMENT; Schema: stayweb; Owner: -
--

COMMENT ON TABLE stayweb.app_data IS 'Stayweb records as key -> JSON. Keys look like <tenant>:<record type>:<id> (e.g. :booking:, :room-inventory:).';


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (product, key);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: tenant_members tenant_members_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_pkey PRIMARY KEY (tenant_id, user_id, product);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: blockchain_proofs blockchain_proofs_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_proofs
    ADD CONSTRAINT blockchain_proofs_pkey PRIMARY KEY (id);


--
-- Name: blockchain_transactions blockchain_transactions_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_pkey PRIMARY KEY (id);


--
-- Name: blockchain_transactions blockchain_transactions_transaction_hash_key; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_transaction_hash_key UNIQUE (transaction_hash);


--
-- Name: credential_attributes credential_attributes_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_attributes
    ADD CONSTRAINT credential_attributes_pkey PRIMARY KEY (id);


--
-- Name: credential_history credential_history_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_history
    ADD CONSTRAINT credential_history_pkey PRIMARY KEY (id);


--
-- Name: credential_metrics credential_metrics_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_metrics
    ADD CONSTRAINT credential_metrics_pkey PRIMARY KEY (id);


--
-- Name: credential_schemas credential_schemas_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_schemas
    ADD CONSTRAINT credential_schemas_pkey PRIMARY KEY (id);


--
-- Name: credential_subjects credential_subjects_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_subjects
    ADD CONSTRAINT credential_subjects_pkey PRIMARY KEY (id);


--
-- Name: credentials credentials_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_pkey PRIMARY KEY (id);


--
-- Name: did_entities did_entities_did_key; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_entities
    ADD CONSTRAINT did_entities_did_key UNIQUE (did);


--
-- Name: did_entities did_entities_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_entities
    ADD CONSTRAINT did_entities_pkey PRIMARY KEY (id);


--
-- Name: did_keys did_keys_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_keys
    ADD CONSTRAINT did_keys_pkey PRIMARY KEY (id);


--
-- Name: document_audit_log document_audit_log_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_audit_log
    ADD CONSTRAINT document_audit_log_pkey PRIMARY KEY (id);


--
-- Name: document_signatures document_signatures_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signatures
    ADD CONSTRAINT document_signatures_pkey PRIMARY KEY (id);


--
-- Name: document_signers document_signers_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signers
    ADD CONSTRAINT document_signers_pkey PRIMARY KEY (id);


--
-- Name: document_versions document_versions_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_versions
    ADD CONSTRAINT document_versions_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: integration_events integration_events_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integration_events
    ADD CONSTRAINT integration_events_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: product_certificates product_certificates_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_certificates
    ADD CONSTRAINT product_certificates_pkey PRIMARY KEY (id);


--
-- Name: product_qr_codes product_qr_codes_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_qr_codes
    ADD CONSTRAINT product_qr_codes_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: qr_scans qr_scans_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.qr_scans
    ADD CONSTRAINT qr_scans_pkey PRIMARY KEY (id);


--
-- Name: schema_attributes schema_attributes_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.schema_attributes
    ADD CONSTRAINT schema_attributes_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: template_elements template_elements_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.template_elements
    ADD CONSTRAINT template_elements_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (tenant_id);


--
-- Name: verification_requests verification_requests_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_requests
    ADD CONSTRAINT verification_requests_pkey PRIMARY KEY (id);


--
-- Name: verification_results verification_results_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_results
    ADD CONSTRAINT verification_results_pkey PRIMARY KEY (id);


--
-- Name: warranties warranties_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranties
    ADD CONSTRAINT warranties_pkey PRIMARY KEY (id);


--
-- Name: warranty_claims warranty_claims_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranty_claims
    ADD CONSTRAINT warranty_claims_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: app_data app_data_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.app_data
    ADD CONSTRAINT app_data_pkey PRIMARY KEY (key);


--
-- Name: document_categories document_categories_name_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.document_categories
    ADD CONSTRAINT document_categories_name_key UNIQUE (name);


--
-- Name: document_categories document_categories_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.document_categories
    ADD CONSTRAINT document_categories_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: employee_onboarding employee_onboarding_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_pkey PRIMARY KEY (id);


--
-- Name: employees employees_email_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_email_key UNIQUE (email);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: employees employees_username_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_username_key UNIQUE (username);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: onboarding_steps onboarding_steps_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.onboarding_steps
    ADD CONSTRAINT onboarding_steps_pkey PRIMARY KEY (id);


--
-- Name: report_dashboards report_dashboards_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.report_dashboards
    ADD CONSTRAINT report_dashboards_pkey PRIMARY KEY (id);


--
-- Name: time_off_balances time_off_balances_employee_id_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_balances
    ADD CONSTRAINT time_off_balances_employee_id_key UNIQUE (employee_id);


--
-- Name: time_off_balances time_off_balances_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_balances
    ADD CONSTRAINT time_off_balances_pkey PRIMARY KEY (id);


--
-- Name: app_data app_data_pkey; Type: CONSTRAINT; Schema: stayweb; Owner: -
--

ALTER TABLE ONLY stayweb.app_data
    ADD CONSTRAINT app_data_pkey PRIMARY KEY (key);


--
-- Name: audit_log_tenant_at_idx; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX audit_log_tenant_at_idx ON core.audit_log USING btree (tenant_id, at DESC);


--
-- Name: sessions_user_idx; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX sessions_user_idx ON core.sessions USING btree (user_id);


--
-- Name: tenant_members_user_idx; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX tenant_members_user_idx ON core.tenant_members USING btree (user_id);


--
-- Name: activity_logs_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX activity_logs_tenant_idx ON docweb.activity_logs USING btree (tenant_id);


--
-- Name: analytics_events_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX analytics_events_tenant_idx ON docweb.analytics_events USING btree (tenant_id);


--
-- Name: api_keys_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX api_keys_tenant_idx ON docweb.api_keys USING btree (tenant_id);


--
-- Name: blockchain_proofs_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX blockchain_proofs_tenant_idx ON docweb.blockchain_proofs USING btree (tenant_id);


--
-- Name: blockchain_transactions_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX blockchain_transactions_tenant_idx ON docweb.blockchain_transactions USING btree (tenant_id);


--
-- Name: credential_attributes_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_attributes_tenant_idx ON docweb.credential_attributes USING btree (tenant_id);


--
-- Name: credential_history_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_history_tenant_idx ON docweb.credential_history USING btree (tenant_id);


--
-- Name: credential_metrics_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_metrics_tenant_idx ON docweb.credential_metrics USING btree (tenant_id);


--
-- Name: credential_schemas_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_schemas_tenant_idx ON docweb.credential_schemas USING btree (tenant_id);


--
-- Name: credential_subjects_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_subjects_tenant_idx ON docweb.credential_subjects USING btree (tenant_id);


--
-- Name: credentials_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credentials_tenant_idx ON docweb.credentials USING btree (tenant_id);


--
-- Name: did_entities_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX did_entities_tenant_idx ON docweb.did_entities USING btree (tenant_id);


--
-- Name: did_keys_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX did_keys_tenant_idx ON docweb.did_keys USING btree (tenant_id);


--
-- Name: document_audit_log_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_audit_log_tenant_idx ON docweb.document_audit_log USING btree (tenant_id);


--
-- Name: document_signatures_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_signatures_tenant_idx ON docweb.document_signatures USING btree (tenant_id);


--
-- Name: document_signers_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_signers_tenant_idx ON docweb.document_signers USING btree (tenant_id);


--
-- Name: document_versions_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_versions_tenant_idx ON docweb.document_versions USING btree (tenant_id);


--
-- Name: documents_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX documents_tenant_idx ON docweb.documents USING btree (tenant_id);


--
-- Name: idx_activity_logs_user; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_activity_logs_user ON docweb.activity_logs USING btree (user_id);


--
-- Name: idx_blockchain_tx_cred; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_blockchain_tx_cred ON docweb.blockchain_transactions USING btree (credential_id);


--
-- Name: idx_credential_history_cred; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_credential_history_cred ON docweb.credential_history USING btree (credential_id);


--
-- Name: idx_credentials_issuer; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_credentials_issuer ON docweb.credentials USING btree (issuer_id);


--
-- Name: idx_credentials_schema; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_credentials_schema ON docweb.credentials USING btree (schema_id);


--
-- Name: idx_credentials_status; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_credentials_status ON docweb.credentials USING btree (status);


--
-- Name: idx_documents_status; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_documents_status ON docweb.documents USING btree (status);


--
-- Name: idx_notifications_status; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_notifications_status ON docweb.notifications USING btree (status);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_notifications_user ON docweb.notifications USING btree (user_id);


--
-- Name: idx_qr_scans_qr; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_qr_scans_qr ON docweb.qr_scans USING btree (qr_code_id);


--
-- Name: idx_verification_req_cred; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_verification_req_cred ON docweb.verification_requests USING btree (credential_id);


--
-- Name: integration_events_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX integration_events_tenant_idx ON docweb.integration_events USING btree (tenant_id);


--
-- Name: integrations_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX integrations_tenant_idx ON docweb.integrations USING btree (tenant_id);


--
-- Name: invoices_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX invoices_tenant_idx ON docweb.invoices USING btree (tenant_id);


--
-- Name: notifications_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX notifications_tenant_idx ON docweb.notifications USING btree (tenant_id);


--
-- Name: product_certificates_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX product_certificates_tenant_idx ON docweb.product_certificates USING btree (tenant_id);


--
-- Name: product_qr_codes_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX product_qr_codes_tenant_idx ON docweb.product_qr_codes USING btree (tenant_id);


--
-- Name: products_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX products_tenant_idx ON docweb.products USING btree (tenant_id);


--
-- Name: qr_scans_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX qr_scans_tenant_idx ON docweb.qr_scans USING btree (tenant_id);


--
-- Name: schema_attributes_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX schema_attributes_tenant_idx ON docweb.schema_attributes USING btree (tenant_id);


--
-- Name: subscription_plans_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX subscription_plans_tenant_idx ON docweb.subscription_plans USING btree (tenant_id);


--
-- Name: subscriptions_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX subscriptions_tenant_idx ON docweb.subscriptions USING btree (tenant_id);


--
-- Name: system_logs_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX system_logs_tenant_idx ON docweb.system_logs USING btree (tenant_id);


--
-- Name: template_elements_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX template_elements_tenant_idx ON docweb.template_elements USING btree (tenant_id);


--
-- Name: templates_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX templates_tenant_idx ON docweb.templates USING btree (tenant_id);


--
-- Name: tenant_settings_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX tenant_settings_tenant_idx ON docweb.tenant_settings USING btree (tenant_id);


--
-- Name: verification_requests_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX verification_requests_tenant_idx ON docweb.verification_requests USING btree (tenant_id);


--
-- Name: verification_results_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX verification_results_tenant_idx ON docweb.verification_results USING btree (tenant_id);


--
-- Name: warranties_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX warranties_tenant_idx ON docweb.warranties USING btree (tenant_id);


--
-- Name: warranty_claims_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX warranty_claims_tenant_idx ON docweb.warranty_claims USING btree (tenant_id);


--
-- Name: webhook_events_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX webhook_events_tenant_idx ON docweb.webhook_events USING btree (tenant_id);


--
-- Name: webhooks_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX webhooks_tenant_idx ON docweb.webhooks USING btree (tenant_id);


--
-- Name: app_data_key_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX app_data_key_idx ON hrweb.app_data USING btree (key text_pattern_ops);


--
-- Name: app_data_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX app_data_tenant_idx ON hrweb.app_data USING btree (tenant_id);


--
-- Name: document_categories_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX document_categories_tenant_idx ON hrweb.document_categories USING btree (tenant_id);


--
-- Name: documents_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX documents_tenant_idx ON hrweb.documents USING btree (tenant_id);


--
-- Name: employee_onboarding_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX employee_onboarding_tenant_idx ON hrweb.employee_onboarding USING btree (tenant_id);


--
-- Name: employees_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX employees_tenant_idx ON hrweb.employees USING btree (tenant_id);


--
-- Name: events_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX events_tenant_idx ON hrweb.events USING btree (tenant_id);


--
-- Name: onboarding_steps_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX onboarding_steps_tenant_idx ON hrweb.onboarding_steps USING btree (tenant_id);


--
-- Name: report_dashboards_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX report_dashboards_tenant_idx ON hrweb.report_dashboards USING btree (tenant_id);


--
-- Name: time_off_balances_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX time_off_balances_tenant_idx ON hrweb.time_off_balances USING btree (tenant_id);


--
-- Name: app_data_key_idx; Type: INDEX; Schema: stayweb; Owner: -
--

CREATE INDEX app_data_key_idx ON stayweb.app_data USING btree (key text_pattern_ops);


--
-- Name: app_data_tenant_idx; Type: INDEX; Schema: stayweb; Owner: -
--

CREATE INDEX app_data_tenant_idx ON stayweb.app_data USING btree (tenant_id);


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: sessions sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sessions
    ADD CONSTRAINT sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: tenant_members tenant_members_invited_by_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES core.users(id);


--
-- Name: tenant_members tenant_members_product_role_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_product_role_fkey FOREIGN KEY (product, role) REFERENCES core.roles(product, key);


--
-- Name: tenant_members tenant_members_tenant_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_members tenant_members_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.activity_logs
    ADD CONSTRAINT activity_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: analytics_events analytics_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.analytics_events
    ADD CONSTRAINT analytics_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: analytics_events analytics_events_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.analytics_events
    ADD CONSTRAINT analytics_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: api_keys api_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.api_keys
    ADD CONSTRAINT api_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: blockchain_proofs blockchain_proofs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_proofs
    ADD CONSTRAINT blockchain_proofs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: blockchain_proofs blockchain_proofs_transaction_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_proofs
    ADD CONSTRAINT blockchain_proofs_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES docweb.blockchain_transactions(id) ON DELETE CASCADE;


--
-- Name: blockchain_transactions blockchain_transactions_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id);


--
-- Name: blockchain_transactions blockchain_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_attributes credential_attributes_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_attributes
    ADD CONSTRAINT credential_attributes_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_attributes credential_attributes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_attributes
    ADD CONSTRAINT credential_attributes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_history credential_history_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_history
    ADD CONSTRAINT credential_history_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_history credential_history_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_history
    ADD CONSTRAINT credential_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_metrics credential_metrics_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_metrics
    ADD CONSTRAINT credential_metrics_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_metrics credential_metrics_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_metrics
    ADD CONSTRAINT credential_metrics_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_schemas credential_schemas_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_schemas
    ADD CONSTRAINT credential_schemas_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_subjects credential_subjects_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_subjects
    ADD CONSTRAINT credential_subjects_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_subjects credential_subjects_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_subjects
    ADD CONSTRAINT credential_subjects_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credentials credentials_issuer_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_issuer_id_fkey FOREIGN KEY (issuer_id) REFERENCES core.users(id);


--
-- Name: credentials credentials_schema_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES docweb.credential_schemas(id);


--
-- Name: credentials credentials_template_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_template_id_fkey FOREIGN KEY (template_id) REFERENCES docweb.templates(id);


--
-- Name: credentials credentials_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: did_entities did_entities_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_entities
    ADD CONSTRAINT did_entities_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: did_keys did_keys_did_entity_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_keys
    ADD CONSTRAINT did_keys_did_entity_id_fkey FOREIGN KEY (did_entity_id) REFERENCES docweb.did_entities(id) ON DELETE CASCADE;


--
-- Name: did_keys did_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_keys
    ADD CONSTRAINT did_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_audit_log document_audit_log_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_audit_log
    ADD CONSTRAINT document_audit_log_document_id_fkey FOREIGN KEY (document_id) REFERENCES docweb.documents(id) ON DELETE CASCADE;


--
-- Name: document_audit_log document_audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_audit_log
    ADD CONSTRAINT document_audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_audit_log document_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_audit_log
    ADD CONSTRAINT document_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: document_signatures document_signatures_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signatures
    ADD CONSTRAINT document_signatures_document_id_fkey FOREIGN KEY (document_id) REFERENCES docweb.documents(id) ON DELETE CASCADE;


--
-- Name: document_signatures document_signatures_signer_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signatures
    ADD CONSTRAINT document_signatures_signer_id_fkey FOREIGN KEY (signer_id) REFERENCES docweb.document_signers(id);


--
-- Name: document_signatures document_signatures_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signatures
    ADD CONSTRAINT document_signatures_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_signers document_signers_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signers
    ADD CONSTRAINT document_signers_document_id_fkey FOREIGN KEY (document_id) REFERENCES docweb.documents(id) ON DELETE CASCADE;


--
-- Name: document_signers document_signers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signers
    ADD CONSTRAINT document_signers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_signers document_signers_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signers
    ADD CONSTRAINT document_signers_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: document_versions document_versions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_versions
    ADD CONSTRAINT document_versions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES core.users(id);


--
-- Name: document_versions document_versions_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_versions
    ADD CONSTRAINT document_versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES docweb.documents(id) ON DELETE CASCADE;


--
-- Name: document_versions document_versions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_versions
    ADD CONSTRAINT document_versions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: documents documents_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.documents
    ADD CONSTRAINT documents_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES core.users(id);


--
-- Name: documents documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.documents
    ADD CONSTRAINT documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: integration_events integration_events_integration_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integration_events
    ADD CONSTRAINT integration_events_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES docweb.integrations(id) ON DELETE CASCADE;


--
-- Name: integration_events integration_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integration_events
    ADD CONSTRAINT integration_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: integrations integrations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integrations
    ADD CONSTRAINT integrations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: invoices invoices_subscription_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.invoices
    ADD CONSTRAINT invoices_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES docweb.subscriptions(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.invoices
    ADD CONSTRAINT invoices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: notifications notifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.notifications
    ADD CONSTRAINT notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: product_certificates product_certificates_product_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_certificates
    ADD CONSTRAINT product_certificates_product_id_fkey FOREIGN KEY (product_id) REFERENCES docweb.products(id) ON DELETE CASCADE;


--
-- Name: product_certificates product_certificates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_certificates
    ADD CONSTRAINT product_certificates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: product_qr_codes product_qr_codes_product_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_qr_codes
    ADD CONSTRAINT product_qr_codes_product_id_fkey FOREIGN KEY (product_id) REFERENCES docweb.products(id) ON DELETE CASCADE;


--
-- Name: product_qr_codes product_qr_codes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_qr_codes
    ADD CONSTRAINT product_qr_codes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: products products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.products
    ADD CONSTRAINT products_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: qr_scans qr_scans_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.qr_scans
    ADD CONSTRAINT qr_scans_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: schema_attributes schema_attributes_schema_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.schema_attributes
    ADD CONSTRAINT schema_attributes_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES docweb.credential_schemas(id) ON DELETE CASCADE;


--
-- Name: schema_attributes schema_attributes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.schema_attributes
    ADD CONSTRAINT schema_attributes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: subscription_plans subscription_plans_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscription_plans
    ADD CONSTRAINT subscription_plans_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: subscriptions subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscriptions
    ADD CONSTRAINT subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES docweb.subscription_plans(id);


--
-- Name: subscriptions subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscriptions
    ADD CONSTRAINT subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: system_logs system_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.system_logs
    ADD CONSTRAINT system_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: template_elements template_elements_template_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.template_elements
    ADD CONSTRAINT template_elements_template_id_fkey FOREIGN KEY (template_id) REFERENCES docweb.templates(id) ON DELETE CASCADE;


--
-- Name: template_elements template_elements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.template_elements
    ADD CONSTRAINT template_elements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: templates templates_schema_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.templates
    ADD CONSTRAINT templates_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES docweb.credential_schemas(id);


--
-- Name: templates templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.templates
    ADD CONSTRAINT templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: tenant_settings tenant_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: verification_requests verification_requests_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_requests
    ADD CONSTRAINT verification_requests_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id);


--
-- Name: verification_requests verification_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_requests
    ADD CONSTRAINT verification_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: verification_results verification_results_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_results
    ADD CONSTRAINT verification_results_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: verification_results verification_results_verification_request_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_results
    ADD CONSTRAINT verification_results_verification_request_id_fkey FOREIGN KEY (verification_request_id) REFERENCES docweb.verification_requests(id) ON DELETE CASCADE;


--
-- Name: warranties warranties_owner_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranties
    ADD CONSTRAINT warranties_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES core.users(id);


--
-- Name: warranties warranties_product_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranties
    ADD CONSTRAINT warranties_product_id_fkey FOREIGN KEY (product_id) REFERENCES docweb.products(id) ON DELETE CASCADE;


--
-- Name: warranties warranties_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranties
    ADD CONSTRAINT warranties_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: warranty_claims warranty_claims_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranty_claims
    ADD CONSTRAINT warranty_claims_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: warranty_claims warranty_claims_warranty_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranty_claims
    ADD CONSTRAINT warranty_claims_warranty_id_fkey FOREIGN KEY (warranty_id) REFERENCES docweb.warranties(id) ON DELETE CASCADE;


--
-- Name: webhook_events webhook_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhook_events
    ADD CONSTRAINT webhook_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: webhook_events webhook_events_webhook_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhook_events
    ADD CONSTRAINT webhook_events_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES docweb.webhooks(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhooks
    ADD CONSTRAINT webhooks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: app_data app_data_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.app_data
    ADD CONSTRAINT app_data_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_categories document_categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.document_categories
    ADD CONSTRAINT document_categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: documents documents_category_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.documents
    ADD CONSTRAINT documents_category_fkey FOREIGN KEY (category_id) REFERENCES hrweb.document_categories(id);


--
-- Name: documents documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.documents
    ADD CONSTRAINT documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: employee_onboarding employee_onboarding_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: employee_onboarding employee_onboarding_step_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_step_fkey FOREIGN KEY (step_id) REFERENCES hrweb.onboarding_steps(id);


--
-- Name: employee_onboarding employee_onboarding_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: employees employees_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: events events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.events
    ADD CONSTRAINT events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: onboarding_steps onboarding_steps_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.onboarding_steps
    ADD CONSTRAINT onboarding_steps_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: report_dashboards report_dashboards_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.report_dashboards
    ADD CONSTRAINT report_dashboards_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: report_dashboards report_dashboards_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.report_dashboards
    ADD CONSTRAINT report_dashboards_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: time_off_balances time_off_balances_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_balances
    ADD CONSTRAINT time_off_balances_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: time_off_balances time_off_balances_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_balances
    ADD CONSTRAINT time_off_balances_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: app_data app_data_tenant_id_fkey; Type: FK CONSTRAINT; Schema: stayweb; Owner: -
--

ALTER TABLE ONLY stayweb.app_data
    ADD CONSTRAINT app_data_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: audit_log; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_members members_self_read; Type: POLICY; Schema: core; Owner: -
--

CREATE POLICY members_self_read ON core.tenant_members FOR SELECT TO authenticated USING ((user_id = auth.uid()));


--
-- Name: roles; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.roles ENABLE ROW LEVEL SECURITY;

--
-- Name: roles roles_read; Type: POLICY; Schema: core; Owner: -
--

CREATE POLICY roles_read ON core.roles FOR SELECT TO authenticated USING (true);


--
-- Name: sessions; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_members; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.tenant_members ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants tenants_member_read; Type: POLICY; Schema: core; Owner: -
--

CREATE POLICY tenants_member_read ON core.tenants FOR SELECT TO authenticated USING ((id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: users; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_self_read; Type: POLICY; Schema: core; Owner: -
--

CREATE POLICY users_self_read ON core.users FOR SELECT TO authenticated USING ((id = auth.uid()));


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.activity_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: analytics_events; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.analytics_events ENABLE ROW LEVEL SECURITY;

--
-- Name: api_keys; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: blockchain_proofs; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.blockchain_proofs ENABLE ROW LEVEL SECURITY;

--
-- Name: blockchain_transactions; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.blockchain_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_attributes; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_attributes ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_history; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_history ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_metrics; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_metrics ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_schemas; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_schemas ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_subjects; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_subjects ENABLE ROW LEVEL SECURITY;

--
-- Name: credentials; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: did_entities; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.did_entities ENABLE ROW LEVEL SECURITY;

--
-- Name: did_keys; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.did_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: document_audit_log; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: document_signatures; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_signatures ENABLE ROW LEVEL SECURITY;

--
-- Name: document_signers; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_signers ENABLE ROW LEVEL SECURITY;

--
-- Name: document_versions; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: documents; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.documents ENABLE ROW LEVEL SECURITY;

--
-- Name: integration_events; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.integration_events ENABLE ROW LEVEL SECURITY;

--
-- Name: integrations; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.integrations ENABLE ROW LEVEL SECURITY;

--
-- Name: invoices; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: product_certificates; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.product_certificates ENABLE ROW LEVEL SECURITY;

--
-- Name: product_qr_codes; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.product_qr_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: products; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.products ENABLE ROW LEVEL SECURITY;

--
-- Name: qr_scans; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.qr_scans ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_attributes; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.schema_attributes ENABLE ROW LEVEL SECURITY;

--
-- Name: subscription_plans; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.subscription_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: subscriptions; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: system_logs; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.system_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: template_elements; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.template_elements ENABLE ROW LEVEL SECURITY;

--
-- Name: templates; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.templates ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.activity_logs AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: analytics_events tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.analytics_events AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: api_keys tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.api_keys AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: blockchain_proofs tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.blockchain_proofs AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: blockchain_transactions tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.blockchain_transactions AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_attributes tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_attributes AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_history tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_history AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_metrics tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_metrics AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_schemas tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_schemas AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_subjects tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_subjects AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credentials tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credentials AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: did_entities tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.did_entities AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: did_keys tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.did_keys AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_audit_log tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_audit_log AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_signatures tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_signatures AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_signers tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_signers AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_versions tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_versions AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: documents tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.documents AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: integration_events tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.integration_events AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: integrations tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.integrations AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: invoices tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.invoices AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: notifications tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.notifications AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: product_certificates tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.product_certificates AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: product_qr_codes tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.product_qr_codes AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: products tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.products AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: qr_scans tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.qr_scans AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: schema_attributes tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.schema_attributes AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: subscription_plans tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.subscription_plans AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: subscriptions tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.subscriptions AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: system_logs tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.system_logs AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: template_elements tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.template_elements AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: templates tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.templates AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: tenant_settings tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.tenant_settings AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: verification_requests tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.verification_requests AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: verification_results tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.verification_results AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: warranties tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.warranties AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: warranty_claims tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.warranty_claims AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: webhook_events tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.webhook_events AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: webhooks tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.webhooks AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: tenant_settings; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.tenant_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: verification_requests; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.verification_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: verification_results; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.verification_results ENABLE ROW LEVEL SECURITY;

--
-- Name: warranties; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.warranties ENABLE ROW LEVEL SECURITY;

--
-- Name: warranty_claims; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.warranty_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: webhook_events; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.webhook_events ENABLE ROW LEVEL SECURITY;

--
-- Name: webhooks; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: app_data; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.app_data ENABLE ROW LEVEL SECURITY;

--
-- Name: document_categories; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.document_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: documents; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.documents ENABLE ROW LEVEL SECURITY;

--
-- Name: employee_onboarding; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.employee_onboarding ENABLE ROW LEVEL SECURITY;

--
-- Name: employees; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.employees ENABLE ROW LEVEL SECURITY;

--
-- Name: events; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.events ENABLE ROW LEVEL SECURITY;

--
-- Name: onboarding_steps; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.onboarding_steps ENABLE ROW LEVEL SECURITY;

--
-- Name: report_dashboards; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.report_dashboards ENABLE ROW LEVEL SECURITY;

--
-- Name: app_data tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.app_data AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_categories tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.document_categories AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: documents tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.documents AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: employee_onboarding tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.employee_onboarding AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: employees tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.employees AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: events tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.events AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: onboarding_steps tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.onboarding_steps AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: report_dashboards tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.report_dashboards AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: time_off_balances tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.time_off_balances AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: time_off_balances; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.time_off_balances ENABLE ROW LEVEL SECURITY;

--
-- Name: app_data; Type: ROW SECURITY; Schema: stayweb; Owner: -
--

ALTER TABLE stayweb.app_data ENABLE ROW LEVEL SECURITY;

--
-- Name: app_data tenant_isolation; Type: POLICY; Schema: stayweb; Owner: -
--

CREATE POLICY tenant_isolation ON stayweb.app_data AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- PostgreSQL database dump complete
--

\unrestrict 7Y4HjkXZG0nT5bzIf2pDPaNBeNqEJFCrK5cs2O06QCskd1uWDnQtUzLn70PRybs

