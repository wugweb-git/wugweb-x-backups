--
-- PostgreSQL database dump
--

\restrict gs9LvZfhGcebZaAsGxe26CRVgjotm3BzG3CtgBSt0dAlbSyLEl3jQfUJAHYzWPw

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: core; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA core;


--
-- Name: SCHEMA core; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA core IS 'Shared across all products: people, tenants (companies), their memberships and roles, sessions and the audit log.';


--
-- Name: docweb; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA docweb;


--
-- Name: SCHEMA docweb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA docweb IS 'DocWeb: documents, verifiable credentials, signing, products and warranties.';


--
-- Name: hrweb; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA hrweb;


--
-- Name: SCHEMA hrweb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA hrweb IS 'HRweb: employees, onboarding, documents, time off. Nookweb-era JSON records live in hrweb.app_data.';


--
-- Name: stayweb; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA stayweb;


--
-- Name: SCHEMA stayweb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA stayweb IS 'Stayweb: property management (rooms, bookings, guests, POS). Data is JSON records in stayweb.app_data.';


--
-- Name: console_decide_signup(uuid, uuid, text, boolean); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.console_decide_signup(p_tenant uuid, p_user uuid, p_product text, p_approve boolean) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
DECLARE v_new text := CASE WHEN p_approve THEN 'active' ELSE 'suspended' END;
BEGIN
  IF NOT core.is_console_owner() THEN
    RAISE EXCEPTION 'Only platform owners can approve sign-ups' USING ERRCODE = '42501';
  END IF;
  UPDATE core.tenant_members SET status = v_new
   WHERE tenant_id = p_tenant AND user_id = p_user AND product = p_product AND status = 'pending';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'No pending sign-up for that person' USING ERRCODE = 'P0002';
  END IF;
  UPDATE core.tenants SET status = v_new WHERE id = p_tenant AND status = 'pending';
  INSERT INTO core.audit_log (tenant_id, user_id, product, action, entity, entity_id, detail)
  VALUES (p_tenant, auth.uid(), 'console', CASE WHEN p_approve THEN 'approve_signup' ELSE 'reject_signup' END,
          'tenant_member', p_user::text, jsonb_build_object('product', p_product));
END; $$;


--
-- Name: console_signups(text); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.console_signups(p_status text DEFAULT 'pending'::text) RETURNS TABLE(tenant_id uuid, tenant_name text, tenant_status text, user_id uuid, email text, name text, product text, role text, member_status text, requested_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
BEGIN
  IF NOT core.is_console_owner() THEN
    RAISE EXCEPTION 'Only platform owners can list sign-ups' USING ERRCODE = '42501';
  END IF;
  RETURN QUERY
    SELECT t.id, t.name, t.status, u.id, u.email, u.name, m.product, m.role, m.status, m.created_at
    FROM core.tenant_members m
    JOIN core.tenants t ON t.id = m.tenant_id
    JOIN core.users u ON u.id = m.user_id
    WHERE m.status = p_status AND m.product <> 'console'
    ORDER BY m.created_at DESC;
END; $$;


--
-- Name: current_tenant_ids(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.current_tenant_ids() RETURNS SETOF uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
  SELECT tenant_id FROM core.tenant_members
  WHERE user_id = auth.uid() AND status = 'active'
$$;


--
-- Name: is_console_owner(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.is_console_owner() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM core.tenant_members
    WHERE user_id = auth.uid() AND product = 'console' AND role = 'owner' AND status = 'active'
  )
$$;


--
-- Name: link_auth_user(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.link_auth_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
BEGIN
  IF NEW.email IS NULL THEN RETURN NEW; END IF;
  -- Existing person (same email): adopt the login's id. New person: create the row.
  UPDATE core.users
     SET id = NEW.id, updated_at = now()
   WHERE lower(email) = lower(NEW.email) AND id <> NEW.id;
  INSERT INTO core.users (id, email, name, phone)
  VALUES (NEW.id, lower(NEW.email), NEW.raw_user_meta_data->>'name', NEW.phone)
  ON CONFLICT (email) DO NOTHING;
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION link_auth_user(); Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON FUNCTION core.link_auth_user() IS 'Links each Supabase Auth login to its person in core.users (by email) and keeps the ids equal.';


--
-- Name: request_access_on_signup(); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.request_access_on_signup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
DECLARE
  v_product text := NEW.raw_user_meta_data->>'signup_product';
  v_company text := nullif(trim(NEW.raw_user_meta_data->>'organization'), '');
  v_role    text;
  v_tenant  uuid;
BEGIN
  v_role := CASE v_product WHEN 'docweb' THEN 'creator' WHEN 'hrweb' THEN 'hr' END;
  IF v_role IS NULL THEN RETURN NEW; END IF;
  IF EXISTS (SELECT 1 FROM core.tenant_members WHERE user_id = NEW.id AND product = v_product) THEN RETURN NEW; END IF;

  INSERT INTO core.tenants (slug, name, status)
  VALUES (
    trim(both '-' from regexp_replace(lower(coalesce(v_company, split_part(NEW.email, '@', 1))), '[^a-z0-9]+', '-', 'g'))
      || '-' || substr(replace(NEW.id::text, '-', ''), 1, 6),
    coalesce(v_company, split_part(NEW.email, '@', 1)),
    'pending')
  RETURNING id INTO v_tenant;

  INSERT INTO core.tenant_members (tenant_id, user_id, product, role, status)
  VALUES (v_tenant, NEW.id, v_product, v_role, 'pending');
  RETURN NEW;
END; $$;


--
-- Name: update_my_profile(text, text); Type: FUNCTION; Schema: core; Owner: -
--

CREATE FUNCTION core.update_my_profile(p_name text, p_phone text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
DECLARE
  v_name  text := nullif(btrim(coalesce(p_name, '')), '');
  v_phone text := nullif(btrim(coalesce(p_phone, '')), '');
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Sign in to change your profile' USING ERRCODE = '42501';
  END IF;
  IF v_name IS NOT NULL AND length(v_name) > 200 THEN
    RAISE EXCEPTION 'The name is too long (200 characters at most)' USING ERRCODE = '22023';
  END IF;
  IF v_phone IS NOT NULL AND (length(v_phone) > 40 OR v_phone !~ '^[0-9+()./ -]+$') THEN
    RAISE EXCEPTION 'Enter a phone number using digits, spaces and + ( ) - . / only' USING ERRCODE = '22023';
  END IF;
  UPDATE core.users SET name = v_name, phone = v_phone, updated_at = now() WHERE id = auth.uid();
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Your account was not found' USING ERRCODE = 'P0002';
  END IF;
END; $_$;


--
-- Name: FUNCTION update_my_profile(p_name text, p_phone text); Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON FUNCTION core.update_my_profile(p_name text, p_phone text) IS 'Signed-in person updates their own core.users name and phone. Email and everything else stay read-only.';


--
-- Name: create_api_key(text, text); Type: FUNCTION; Schema: docweb; Owner: -
--

CREATE FUNCTION docweb.create_api_key(p_name text, p_role text DEFAULT 'full'::text) RETURNS TABLE(id text, key text, key_prefix text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
DECLARE
  v_tenant uuid;
  v_key    text;
  v_id     text := gen_random_uuid()::text;
BEGIN
  SELECT m.tenant_id INTO v_tenant FROM core.tenant_members m
   WHERE m.user_id = auth.uid() AND m.product = 'docweb' AND m.status = 'active' LIMIT 1;
  IF v_tenant IS NULL THEN
    RAISE EXCEPTION 'Only active DocWeb members can create API keys' USING ERRCODE = '42501';
  END IF;
  IF coalesce(trim(p_name), '') = '' THEN
    RAISE EXCEPTION 'Give the key a name' USING ERRCODE = '22023';
  END IF;
  v_key := 'dwk_live_' || encode(extensions.gen_random_bytes(24), 'hex');
  INSERT INTO docweb.api_keys (id, name, key_hash, key_prefix, role, status, created_at, tenant_id)
  VALUES (v_id, trim(p_name), encode(extensions.digest(v_key, 'sha256'), 'hex'), left(v_key, 16),
          coalesce(p_role, 'full'), 'active', now()::text, v_tenant);
  RETURN QUERY SELECT v_id, v_key, left(v_key, 16);
END; $$;


--
-- Name: public_product(text, boolean); Type: FUNCTION; Schema: docweb; Owner: -
--

CREATE FUNCTION docweb.public_product(p_product_id text, p_record_scan boolean DEFAULT true) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
DECLARE
  v_id     text := btrim(coalesce(p_product_id, ''));
  v_p      docweb.products%ROWTYPE;
  v_issuer text;
  v_qr     text;
  v_certs  jsonb;
  v_warr   jsonb;
  v_ip     text;
  v_ua     text;
BEGIN
  IF v_id = '' OR length(v_id) > 100 THEN
    RETURN jsonb_build_object('found', false);
  END IF;
  SELECT * INTO v_p FROM docweb.products p WHERE p.id = v_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('found', false);
  END IF;

  SELECT t.name INTO v_issuer FROM core.tenants t WHERE t.id = v_p.tenant_id;
  SELECT coalesce(jsonb_agg(jsonb_build_object('type', pc.certificate_type, 'issued_at', pc.issued_at) ORDER BY pc.issued_at, pc.certificate_type), '[]'::jsonb)
    INTO v_certs FROM docweb.product_certificates pc WHERE pc.product_id = v_p.id;
  SELECT jsonb_build_object(
           'registered', count(*),
           'active',  count(*) FILTER (WHERE w.status = 'active'),
           'expired', count(*) FILTER (WHERE w.status = 'expired'),
           'claimed', count(*) FILTER (WHERE w.status = 'claimed'))
    INTO v_warr FROM docweb.warranties w WHERE w.product_id = v_p.id;

  IF p_record_scan THEN
    SELECT q.id INTO v_qr FROM docweb.product_qr_codes q WHERE q.product_id = v_p.id ORDER BY q.created_at DESC LIMIT 1;
    SELECT rc.ip, rc.user_agent INTO v_ip, v_ua FROM docweb.request_client() rc;
    INSERT INTO docweb.qr_scans (id, qr_code_id, scanned_at, ip_address, location, device, tenant_id)
    VALUES (gen_random_uuid()::text, coalesce(v_qr, v_p.id), now()::text, v_ip, NULL, v_ua, v_p.tenant_id);
  END IF;

  RETURN jsonb_build_object(
    'found', true,
    'id', v_p.id,
    'product_name', v_p.product_name,
    'manufacturer', v_p.manufacturer,
    'batch_number', v_p.batch_number,
    'manufacture_date', v_p.manufacture_date,
    'expiry_date', v_p.expiry_date,
    'created_at', v_p.created_at,
    'issuer_name', v_issuer,
    'certificates', v_certs,
    'warranty', v_warr
  );
END; $$;


--
-- Name: FUNCTION public_product(p_product_id text, p_record_scan boolean); Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON FUNCTION docweb.public_product(p_product_id text, p_record_scan boolean) IS 'Public product authenticity page (no sign-in). Returns one product''s public fields, the issuing company''s name, its certificate types (no files) and warranty counts by status (no owners). Logs a qr_scans row (qr_code_id = the product''s latest product_qr_codes.id, else the product id) unless p_record_scan is false.';


--
-- Name: public_verify(text, text); Type: FUNCTION; Schema: docweb; Owner: -
--

CREATE FUNCTION docweb.public_verify(p_query text, p_method text DEFAULT 'manual'::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
DECLARE
  v_q        text := btrim(coalesce(p_query, ''));
  v_method   text := CASE WHEN p_method IN ('QR', 'API', 'manual') THEN p_method ELSE 'manual' END;
  v_hash     text;
  v_today    text := to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD');
  v_type     text;
  v_tenant   uuid;
  v_record   text;
  v_status   text;
  v_name     text;
  v_schema   text;
  v_subject  text;
  v_issued   text;
  v_expires  text;
  v_revoked  text;
  v_hashout  text;
  v_tx       text;
  v_network  text;
  v_issuer   text;
  v_ip       text;
  v_ua       text;
  v_req      text := gen_random_uuid()::text;
BEGIN
  IF v_q = '' OR length(v_q) > 200 THEN
    RETURN jsonb_build_object('found', false, 'status', 'not_found');
  END IF;
  v_hash := lower(regexp_replace(v_q, '^0x', '', 'i'));

  IF v_hash ~ '^[0-9a-f]{64}$' THEN
    SELECT 'document', d.tenant_id, d.id,
           CASE d.status WHEN 'certified' THEN 'valid' ELSE 'expired' END,
           d.title, 'Document', d.created_at, NULL, NULL, lower(d.sha256_hash)
      INTO v_type, v_tenant, v_record, v_status, v_name, v_schema, v_issued, v_expires, v_revoked, v_hashout
      FROM docweb.documents d
     WHERE lower(d.sha256_hash) = v_hash AND d.status IN ('certified', 'archived')
     ORDER BY (d.status = 'certified') DESC, d.updated_at DESC
     LIMIT 1;

    IF v_type IS NULL THEN
      SELECT 'attestation', a.tenant_id, a.id,
             CASE WHEN a.status = 'revoked' THEN 'revoked'
                  WHEN a.status = 'expired' OR (a.expires_at IS NOT NULL AND a.expires_at < current_date) THEN 'expired'
                  ELSE 'valid' END,
             a.document_name, 'Self-attestation', a.attested_at::text, a.expires_at::text, a.revoked_at::text, a.document_hash, a.blockchain_tx
        INTO v_type, v_tenant, v_record, v_status, v_name, v_schema, v_issued, v_expires, v_revoked, v_hashout, v_tx
        FROM docweb.attestations a
       WHERE a.document_hash = v_hash
       ORDER BY (a.status <> 'revoked') DESC, a.attested_at DESC
       LIMIT 1;
    END IF;

    IF v_type IS NULL THEN
      SELECT c.id INTO v_record
        FROM docweb.credentials c
       WHERE lower(regexp_replace(coalesce(c.blockchain_hash, ''), '^0x', '', 'i')) = v_hash
         AND c.status IN ('issued', 'revoked', 'expired')
       ORDER BY c.issued_at DESC NULLS LAST
       LIMIT 1;
      IF v_record IS NOT NULL THEN v_type := 'credential'; END IF;
    END IF;
  ELSE
    SELECT c.id INTO v_record
      FROM docweb.credentials c
     WHERE c.id = v_q AND c.status IN ('issued', 'revoked', 'expired');
    IF v_record IS NOT NULL THEN v_type := 'credential'; END IF;
  END IF;

  IF v_type IS NULL THEN
    RETURN jsonb_build_object('found', false, 'status', 'not_found');
  END IF;

  IF v_type = 'credential' THEN
    SELECT c.tenant_id,
           CASE WHEN c.status = 'revoked' THEN 'revoked'
                WHEN c.status = 'expired' OR (c.expires_at IS NOT NULL AND left(c.expires_at, 10) < v_today) THEN 'expired'
                ELSE 'valid' END,
           s.name, s.name, c.issued_at, c.expires_at, c.revoked_at, c.blockchain_hash
      INTO v_tenant, v_status, v_name, v_schema, v_issued, v_expires, v_revoked, v_hashout
      FROM docweb.credentials c
      LEFT JOIN docweb.credential_schemas s ON s.id = c.schema_id
     WHERE c.id = v_record;
    SELECT cs.subject_name INTO v_subject
      FROM docweb.credential_subjects cs WHERE cs.credential_id = v_record ORDER BY cs.id LIMIT 1;
    SELECT bt.transaction_hash, bt.blockchain_network INTO v_tx, v_network
      FROM docweb.blockchain_transactions bt
     WHERE bt.credential_id = v_record AND bt.status = 'confirmed'
     ORDER BY bt.anchored_at DESC LIMIT 1;
  END IF;

  SELECT t.name INTO v_issuer FROM core.tenants t WHERE t.id = v_tenant;

  SELECT rc.ip, rc.user_agent INTO v_ip, v_ua FROM docweb.request_client() rc;
  INSERT INTO docweb.verification_requests (id, credential_id, requester_ip, verification_method, timestamp, tenant_id)
  VALUES (v_req, CASE WHEN v_type = 'credential' THEN v_record END, v_ip, v_method, now()::text, v_tenant);
  INSERT INTO docweb.verification_results (id, verification_request_id, status, message, timestamp, tenant_id)
  VALUES (gen_random_uuid()::text, v_req, v_status, v_type || ':' || v_record, now()::text, v_tenant);
  IF v_method = 'QR' THEN
    INSERT INTO docweb.qr_scans (id, qr_code_id, scanned_at, ip_address, location, device, tenant_id)
    VALUES (gen_random_uuid()::text, v_record, now()::text, v_ip, NULL, v_ua, v_tenant);
  END IF;
  IF v_type = 'credential' THEN
    UPDATE docweb.credential_metrics SET verifications = verifications + 1 WHERE credential_id = v_record;
    IF NOT FOUND THEN
      INSERT INTO docweb.credential_metrics (id, credential_id, verifications, tenant_id)
      VALUES (gen_random_uuid()::text, v_record, 1, v_tenant);
    END IF;
  END IF;

  RETURN jsonb_build_object(
    'found', true,
    'type', v_type,
    'status', v_status,
    'credential_id', CASE WHEN v_type = 'credential' THEN v_record END,
    'name', v_name,
    'schema_name', v_schema,
    'issuer_name', v_issuer,
    'subject_name', v_subject,
    'issued_at', v_issued,
    'expires_at', v_expires,
    'revoked_at', v_revoked,
    'document_hash', v_hashout,
    'transaction_hash', v_tx,
    'network', v_network
  );
END; $_$;


--
-- Name: FUNCTION public_verify(p_query text, p_method text); Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON FUNCTION docweb.public_verify(p_query text, p_method text) IS 'Public verification (no sign-in). p_query: a credential id, or a SHA-256 (64 hex, optional 0x) of a certified document, a self-attestation or an anchored credential. p_method: manual | QR | API. Returns found, type, status (valid / revoked / expired / not_found), issuer company name, subject display name (credentials only), record and schema name, dates, public hashes. Never returns emails, people''s ids or other records. Logs found lookups in verification_requests / verification_results (and qr_scans for QR) under the owning company.';


--
-- Name: request_client(); Type: FUNCTION; Schema: docweb; Owner: -
--

CREATE FUNCTION docweb.request_client() RETURNS TABLE(ip text, user_agent text)
    LANGUAGE plpgsql STABLE
    SET search_path TO ''
    AS $$
DECLARE v_headers jsonb;
BEGIN
  BEGIN
    v_headers := nullif(current_setting('request.headers', true), '')::jsonb;
  EXCEPTION WHEN others THEN
    v_headers := NULL;
  END;
  RETURN QUERY SELECT
    left(nullif(btrim(split_part(coalesce(v_headers ->> 'x-forwarded-for', v_headers ->> 'x-real-ip', ''), ',', 1)), ''), 64),
    left(nullif(v_headers ->> 'user-agent', ''), 300);
END; $$;


--
-- Name: FUNCTION request_client(); Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON FUNCTION docweb.request_client() IS 'Internal helper for the public functions: caller IP and user agent from the Data API request headers.';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: hrweb; Owner: -
--

CREATE FUNCTION hrweb.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END; $$;


--
-- Name: FUNCTION set_updated_at(); Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON FUNCTION hrweb.set_updated_at() IS 'Trigger: keeps updated_at current on every UPDATE of an hrweb table.';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.audit_log (
    id bigint NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    product text,
    action text NOT NULL,
    entity text,
    entity_id text,
    detail jsonb,
    ip inet
);


--
-- Name: TABLE audit_log; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.audit_log IS 'Who did what, when, in which tenant and product.';


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

ALTER TABLE core.audit_log ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME core.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: roles; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.roles (
    product text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    landing text
);


--
-- Name: TABLE roles; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.roles IS 'Roles each product offers (e.g. HRweb: HR / Employee) and which side of the product they land on.';


--
-- Name: sessions; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid,
    product text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    user_agent text,
    ip inet
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.sessions IS 'Signed-in sessions across products.';


--
-- Name: tenant_members; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.tenant_members (
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    product text NOT NULL,
    role text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    invited_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_members_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'invited'::text, 'active'::text, 'suspended'::text])))
);


--
-- Name: TABLE tenant_members; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.tenant_members IS 'Who belongs to which tenant, in which product, with which role.';


--
-- Name: COLUMN tenant_members.status; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON COLUMN core.tenant_members.status IS 'pending = asked to join (self sign-up), waiting for approval; invited; active; suspended.';


--
-- Name: tenants; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    tier text DEFAULT 'free'::text NOT NULL,
    domains text[] DEFAULT '{}'::text[] NOT NULL,
    db_location text DEFAULT 'shared'::text NOT NULL,
    db_config jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    CONSTRAINT tenants_db_location_check CHECK ((db_location = ANY (ARRAY['shared'::text, 'dedicated'::text]))),
    CONSTRAINT tenants_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'suspended'::text]))),
    CONSTRAINT tenants_tier_check CHECK ((tier = ANY (ARRAY['free'::text, 'paid'::text])))
);


--
-- Name: TABLE tenants; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.tenants IS 'A customer company. Wugweb is tenant #1. Tier (free/paid), custom domains and where its database lives.';


--
-- Name: COLUMN tenants.status; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON COLUMN core.tenants.status IS 'pending = signed up, waiting for a Wugweb admin to approve; active; suspended.';


--
-- Name: users; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    name text,
    phone text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE users; Type: COMMENT; Schema: core; Owner: -
--

COMMENT ON TABLE core.users IS 'One account per person (by email), shared by every product.';


--
-- Name: activity_logs; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.activity_logs (
    id text NOT NULL,
    user_id uuid,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    metadata text,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: analytics_events; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.analytics_events (
    id text NOT NULL,
    event_type text NOT NULL,
    user_id uuid,
    metadata text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: api_keys; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.api_keys (
    id text NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    role text DEFAULT 'read_only'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    last_used_at text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT api_keys_role_check CHECK ((role = ANY (ARRAY['full'::text, 'read_only'::text, 'certify_only'::text]))),
    CONSTRAINT api_keys_status_check CHECK ((status = ANY (ARRAY['active'::text, 'revoked'::text])))
);


--
-- Name: attestations; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.attestations (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    tenant_id uuid NOT NULL,
    document_name text NOT NULL,
    category text NOT NULL,
    description text,
    attested_by_user_id uuid DEFAULT auth.uid() NOT NULL,
    file_path text,
    file_name text,
    file_type text,
    file_size bigint,
    document_hash text NOT NULL,
    status text DEFAULT 'verified'::text NOT NULL,
    expires_at date,
    blockchain_tx text,
    attested_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT attestations_category_check CHECK ((category = ANY (ARRAY['expense'::text, 'insurance'::text, 'declaration'::text, 'education'::text, 'financial'::text, 'invoice'::text]))),
    CONSTRAINT attestations_check CHECK (((file_path IS NULL) OR (file_path ~~ ((tenant_id)::text || '/attestations/%'::text)))),
    CONSTRAINT attestations_description_check CHECK (((description IS NULL) OR (length(description) <= 2000))),
    CONSTRAINT attestations_document_hash_check CHECK ((document_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT attestations_document_name_check CHECK (((length(btrim(document_name)) >= 1) AND (length(btrim(document_name)) <= 300))),
    CONSTRAINT attestations_file_name_check CHECK (((file_name IS NULL) OR (length(file_name) <= 300))),
    CONSTRAINT attestations_file_size_check CHECK (((file_size IS NULL) OR (file_size >= 0))),
    CONSTRAINT attestations_status_check CHECK ((status = ANY (ARRAY['verified'::text, 'pending'::text, 'expired'::text, 'revoked'::text])))
);


--
-- Name: TABLE attestations; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON TABLE docweb.attestations IS 'Self-attestations: a member declares a document authentic. Stores the SHA-256 of the file (hashed in the browser), who attested and when. The file itself is in the private docweb-documents bucket at file_path (<tenant id>/attestations/<id>/<file>).';


--
-- Name: COLUMN attestations.attested_by_user_id; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.attestations.attested_by_user_id IS 'The member who attested (core.users.id). Must be the signed-in person on insert.';


--
-- Name: COLUMN attestations.document_hash; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.attestations.document_hash IS 'Lowercase hex SHA-256 of the attested file. Public verification can look an attestation up by this hash.';


--
-- Name: COLUMN attestations.status; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.attestations.status IS 'verified (attested), pending, expired, revoked.';


--
-- Name: COLUMN attestations.blockchain_tx; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.attestations.blockchain_tx IS 'Anchoring transaction, once blockchain anchoring exists (not built yet).';


--
-- Name: blockchain_proofs; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.blockchain_proofs (
    id text NOT NULL,
    transaction_id text NOT NULL,
    proof_type text NOT NULL,
    proof_data text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT blockchain_proofs_proof_type_check CHECK ((proof_type = ANY (ARRAY['merkle'::text, 'zk'::text, 'signature'::text])))
);


--
-- Name: blockchain_transactions; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.blockchain_transactions (
    id text NOT NULL,
    credential_id text,
    transaction_hash text NOT NULL,
    blockchain_network text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    gas_used integer,
    anchored_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT blockchain_transactions_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'confirmed'::text, 'failed'::text])))
);


--
-- Name: credential_attributes; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_attributes (
    id text NOT NULL,
    credential_id text NOT NULL,
    attribute_name text NOT NULL,
    attribute_value text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: credential_history; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_history (
    id text NOT NULL,
    credential_id text NOT NULL,
    event_type text NOT NULL,
    event_data text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT credential_history_event_type_check CHECK ((event_type = ANY (ARRAY['issued'::text, 'verified'::text, 'revoked'::text, 'updated'::text])))
);


--
-- Name: credential_metrics; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_metrics (
    id text NOT NULL,
    credential_id text NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    downloads integer DEFAULT 0 NOT NULL,
    shares integer DEFAULT 0 NOT NULL,
    verifications integer DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: credential_schemas; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_schemas (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    version text DEFAULT '1.0'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT credential_schemas_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'deprecated'::text])))
);


--
-- Name: credential_subjects; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credential_subjects (
    id text NOT NULL,
    credential_id text NOT NULL,
    subject_identifier text NOT NULL,
    subject_name text NOT NULL,
    subject_email text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: credentials; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.credentials (
    id text NOT NULL,
    schema_id text NOT NULL,
    template_id text,
    issuer_id uuid NOT NULL,
    subject_id text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    blockchain_hash text,
    issued_at text,
    expires_at text,
    revoked_at text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT credentials_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'issued'::text, 'revoked'::text, 'expired'::text])))
);


--
-- Name: did_entities; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.did_entities (
    id text NOT NULL,
    did text NOT NULL,
    public_key text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT did_entities_status_check CHECK ((status = ANY (ARRAY['active'::text, 'revoked'::text])))
);


--
-- Name: did_keys; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.did_keys (
    id text NOT NULL,
    did_entity_id text NOT NULL,
    key_type text NOT NULL,
    public_key text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT did_keys_key_type_check CHECK ((key_type = ANY (ARRAY['Ed25519'::text, 'secp256k1'::text, 'RSA'::text])))
);


--
-- Name: document_audit_log; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_audit_log (
    id text NOT NULL,
    document_id text NOT NULL,
    action text NOT NULL,
    user_id uuid,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    metadata text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: document_folders; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_folders (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    created_by_user_id uuid DEFAULT auth.uid(),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT document_folders_name_check CHECK (((length(btrim(name)) >= 1) AND (length(btrim(name)) <= 100)))
);


--
-- Name: TABLE document_folders; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON TABLE docweb.document_folders IS 'Folders in a company''s document library. Folder names are unique per company (case-insensitive).';


--
-- Name: document_shares; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_shares (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    tenant_id uuid NOT NULL,
    document_id text NOT NULL,
    shared_with_email text NOT NULL,
    expires_at date,
    shared_by_user_id uuid DEFAULT auth.uid(),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT document_shares_shared_with_email_check CHECK (((length(shared_with_email) <= 320) AND (shared_with_email ~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'::text)))
);


--
-- Name: TABLE document_shares; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON TABLE docweb.document_shares IS 'Who a document was shared with (an email address typed by a member) and until when. Recorded only: no email is sent and no outside access is granted yet.';


--
-- Name: document_signatures; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_signatures (
    id text NOT NULL,
    document_id text NOT NULL,
    signer_id text NOT NULL,
    signature_data text NOT NULL,
    signature_type text NOT NULL,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT document_signatures_signature_type_check CHECK ((signature_type = ANY (ARRAY['drawn'::text, 'digital'::text, 'cryptographic'::text])))
);


--
-- Name: document_signers; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_signers (
    id text NOT NULL,
    document_id text NOT NULL,
    user_id uuid,
    signer_email text,
    signer_name text,
    sign_order integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    signed_at text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT document_signers_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'signed'::text, 'rejected'::text])))
);


--
-- Name: document_stars; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_stars (
    tenant_id uuid NOT NULL,
    document_id text NOT NULL,
    user_id uuid DEFAULT auth.uid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE document_stars; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON TABLE docweb.document_stars IS 'Documents a person has starred. Personal: each person sees and changes only their own stars.';


--
-- Name: document_versions; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.document_versions (
    id text NOT NULL,
    document_id text NOT NULL,
    version_number integer NOT NULL,
    file_url text NOT NULL,
    sha256_hash text,
    created_at text DEFAULT (now())::text NOT NULL,
    created_by_user_id uuid NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.documents (
    id text NOT NULL,
    created_by_user_id uuid NOT NULL,
    file_url text NOT NULL,
    title text NOT NULL,
    file_type text,
    file_size integer,
    sha256_hash text,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    updated_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    folder_id text,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT documents_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'certified'::text, 'archived'::text]))),
    CONSTRAINT documents_tags_check CHECK ((cardinality(tags) <= 20))
);


--
-- Name: COLUMN documents.folder_id; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.documents.folder_id IS 'Folder in the library (docweb.document_folders); null = no folder. Deleting the folder clears it.';


--
-- Name: COLUMN documents.tags; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.documents.tags IS 'Free-text tags shown in the library (at most 20).';


--
-- Name: integration_events; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.integration_events (
    id text NOT NULL,
    integration_id text NOT NULL,
    event_type text NOT NULL,
    payload text,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT integration_events_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processed'::text, 'failed'::text])))
);


--
-- Name: integrations; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.integrations (
    id text NOT NULL,
    provider text NOT NULL,
    api_key text,
    webhook_url text,
    status text DEFAULT 'active'::text NOT NULL,
    config text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT integrations_status_check CHECK ((status = ANY (ARRAY['active'::text, 'disconnected'::text, 'error'::text])))
);


--
-- Name: invoices; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.invoices (
    id text NOT NULL,
    subscription_id text NOT NULL,
    amount real NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    issued_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT invoices_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'sent'::text, 'paid'::text, 'overdue'::text])))
);


--
-- Name: notifications; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.notifications (
    id text NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    title text,
    message text NOT NULL,
    status text DEFAULT 'unread'::text NOT NULL,
    metadata text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT notifications_status_check CHECK ((status = ANY (ARRAY['unread'::text, 'read'::text, 'dismissed'::text])))
);


--
-- Name: product_certificates; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.product_certificates (
    id text NOT NULL,
    product_id text NOT NULL,
    certificate_type text NOT NULL,
    certificate_file text,
    issued_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: product_qr_codes; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.product_qr_codes (
    id text NOT NULL,
    product_id text NOT NULL,
    qr_code_url text NOT NULL,
    verification_url text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.products (
    id text NOT NULL,
    product_name text NOT NULL,
    manufacturer text,
    batch_number text,
    manufacture_date text,
    expiry_date text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: qr_scans; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.qr_scans (
    id text NOT NULL,
    qr_code_id text NOT NULL,
    scanned_at text DEFAULT (now())::text NOT NULL,
    ip_address text,
    location text,
    device text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: schema_attributes; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.schema_attributes (
    id text NOT NULL,
    schema_id text NOT NULL,
    attribute_name text NOT NULL,
    attribute_type text NOT NULL,
    required integer DEFAULT 0 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT schema_attributes_attribute_type_check CHECK ((attribute_type = ANY (ARRAY['string'::text, 'number'::text, 'date'::text, 'boolean'::text])))
);


--
-- Name: subscription_plans; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    price real NOT NULL,
    credential_limit integer,
    api_limit integer,
    features text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.subscriptions (
    id text NOT NULL,
    plan_id text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    started_at text DEFAULT (now())::text NOT NULL,
    expires_at text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT subscriptions_status_check CHECK ((status = ANY (ARRAY['active'::text, 'past_due'::text, 'cancelled'::text])))
);


--
-- Name: system_logs; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.system_logs (
    id text NOT NULL,
    service text NOT NULL,
    level text NOT NULL,
    message text NOT NULL,
    metadata text,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT system_logs_level_check CHECK ((level = ANY (ARRAY['debug'::text, 'info'::text, 'warn'::text, 'error'::text, 'critical'::text])))
);


--
-- Name: template_elements; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.template_elements (
    id text NOT NULL,
    template_id text NOT NULL,
    element_type text NOT NULL,
    position_x real DEFAULT 0 NOT NULL,
    position_y real DEFAULT 0 NOT NULL,
    width real DEFAULT 100 NOT NULL,
    height real DEFAULT 40 NOT NULL,
    data_binding text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT template_elements_element_type_check CHECK ((element_type = ANY (ARRAY['text'::text, 'image'::text, 'QR'::text, 'table'::text, 'HTML'::text])))
);


--
-- Name: templates; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.templates (
    id text NOT NULL,
    schema_id text,
    name text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT templates_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'archived'::text])))
);


--
-- Name: tenant_settings; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.tenant_settings (
    tenant_id uuid NOT NULL,
    branding_color text,
    default_template_id text,
    default_schema_id text,
    accent_color text,
    logo_path text,
    favicon_path text,
    certificate_template text,
    updated_at timestamp with time zone,
    CONSTRAINT tenant_settings_accent_color_check CHECK (((accent_color IS NULL) OR (accent_color ~ '^#[0-9A-Fa-f]{6}$'::text))),
    CONSTRAINT tenant_settings_certificate_template_check CHECK (((certificate_template IS NULL) OR (length(certificate_template) <= 50))),
    CONSTRAINT tenant_settings_check CHECK (((logo_path IS NULL) OR (logo_path ~~ ((tenant_id)::text || '/branding/%'::text)))),
    CONSTRAINT tenant_settings_check1 CHECK (((favicon_path IS NULL) OR (favicon_path ~~ ((tenant_id)::text || '/branding/%'::text))))
);


--
-- Name: TABLE tenant_settings; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON TABLE docweb.tenant_settings IS 'Per-tenant DocWeb settings: brand colours, logo, favicon, certificate look, default template and credential schema.';


--
-- Name: COLUMN tenant_settings.branding_color; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.tenant_settings.branding_color IS 'Primary brand colour (#RRGGBB).';


--
-- Name: COLUMN tenant_settings.accent_color; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.tenant_settings.accent_color IS 'Accent brand colour (#RRGGBB).';


--
-- Name: COLUMN tenant_settings.logo_path; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.tenant_settings.logo_path IS 'Company logo in the private docweb-documents bucket (<tenant id>/branding/...). Shown through short-lived signed URLs.';


--
-- Name: COLUMN tenant_settings.favicon_path; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.tenant_settings.favicon_path IS 'Favicon in the private docweb-documents bucket (<tenant id>/branding/...).';


--
-- Name: COLUMN tenant_settings.certificate_template; Type: COMMENT; Schema: docweb; Owner: -
--

COMMENT ON COLUMN docweb.tenant_settings.certificate_template IS 'Chosen certificate look (id from the Branding screen, e.g. professional).';


--
-- Name: verification_requests; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.verification_requests (
    id text NOT NULL,
    credential_id text,
    requester_ip text,
    verification_method text NOT NULL,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT verification_requests_verification_method_check CHECK ((verification_method = ANY (ARRAY['QR'::text, 'API'::text, 'manual'::text])))
);


--
-- Name: verification_results; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.verification_results (
    id text NOT NULL,
    verification_request_id text NOT NULL,
    status text NOT NULL,
    message text,
    "timestamp" text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT verification_results_status_check CHECK ((status = ANY (ARRAY['valid'::text, 'invalid'::text, 'expired'::text, 'revoked'::text])))
);


--
-- Name: warranties; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.warranties (
    id text NOT NULL,
    product_id text NOT NULL,
    owner_id uuid,
    purchase_date text,
    registered_at text DEFAULT (now())::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT warranties_status_check CHECK ((status = ANY (ARRAY['active'::text, 'expired'::text, 'claimed'::text])))
);


--
-- Name: warranty_claims; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.warranty_claims (
    id text NOT NULL,
    warranty_id text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'submitted'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT warranty_claims_status_check CHECK ((status = ANY (ARRAY['submitted'::text, 'under_review'::text, 'approved'::text, 'rejected'::text])))
);


--
-- Name: webhook_events; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.webhook_events (
    id text NOT NULL,
    webhook_id text NOT NULL,
    event_type text NOT NULL,
    payload text NOT NULL,
    response_status integer,
    response_body text,
    delivered_at text,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: webhooks; Type: TABLE; Schema: docweb; Owner: -
--

CREATE TABLE docweb.webhooks (
    id text NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    secret text,
    events text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at text DEFAULT (now())::text NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    CONSTRAINT webhooks_status_check CHECK ((status = ANY (ARRAY['active'::text, 'paused'::text, 'failed'::text])))
);


--
-- Name: announcements; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.announcements (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    author_employee_id integer,
    priority text DEFAULT 'normal'::text NOT NULL,
    target_audience text DEFAULT 'all'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT announcements_priority_check CHECK ((priority = ANY (ARRAY['low'::text, 'normal'::text, 'high'::text, 'urgent'::text])))
);


--
-- Name: TABLE announcements; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.announcements IS 'Company announcements written by HR (was app_data "announcement:"). Everyone in the company can read them.';


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.announcements ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: app_data; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.app_data (
    key text NOT NULL,
    value jsonb NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: TABLE app_data; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.app_data IS 'Legacy key -> JSON records from the Figma Make era. No longer read or written by hrweb-api (12_hrweb_tables.sql moved everything into tables); kept for reference.';


--
-- Name: articles; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.articles (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    author_employee_id integer,
    views integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE articles; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.articles IS 'Knowledge-sharing articles (was app_data "article:"). Everyone reads; the author or HR edits.';


--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.articles ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: benefit_enrollments; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.benefit_enrollments (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    employee_id integer NOT NULL,
    benefit_id bigint NOT NULL,
    start_date date DEFAULT CURRENT_DATE NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    enrolled_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE benefit_enrollments; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.benefit_enrollments IS 'An employee''s enrolment in a benefit plan (was app_data "benefit_enrollment:").';


--
-- Name: benefit_enrollments_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.benefit_enrollments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.benefit_enrollments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: benefits; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.benefits (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    type text NOT NULL,
    provider text DEFAULT ''::text NOT NULL,
    cost numeric(12,2) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE benefits; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.benefits IS 'Benefit plans offered by the company (was app_data "benefit:"). type: health, dental, vision, life, retirement...; cost per month.';


--
-- Name: benefits_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.benefits ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.benefits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: company_profile; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.company_profile (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    name text NOT NULL,
    industry text,
    email text,
    phone text,
    website text,
    address text,
    employee_count text,
    founded_year text,
    description text,
    logo text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    legal_name text,
    registration_number text,
    city text,
    state text,
    country text,
    postal_code text,
    signatory_name text,
    signatory_title text
);


--
-- Name: TABLE company_profile; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.company_profile IS 'One company profile per tenant (was app_data "org:<orgId>"). The company itself is core.tenants; this holds the HR-facing details. HR edits, everyone reads.';


--
-- Name: COLUMN company_profile.address; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.address IS 'Registered office address (street lines). Used by generated documents together with city, state, postal_code and country.';


--
-- Name: COLUMN company_profile.legal_name; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.legal_name IS 'Registered legal name used in letters and agreements (e.g. "Acme Private Limited"). Empty = name.';


--
-- Name: COLUMN company_profile.registration_number; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.registration_number IS 'Company registration number (CIN or equivalent), printed on agreements when present.';


--
-- Name: COLUMN company_profile.city; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.city IS 'City of the registered office; also the place of signing on letters.';


--
-- Name: COLUMN company_profile.state; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.state IS 'State / region of the registered office; the default governing state of agreements.';


--
-- Name: COLUMN company_profile.country; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.country IS 'Country of the registered office.';


--
-- Name: COLUMN company_profile.postal_code; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.postal_code IS 'Postal / PIN code of the registered office.';


--
-- Name: COLUMN company_profile.signatory_name; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.signatory_name IS 'Person who signs generated letters and agreements for the company.';


--
-- Name: COLUMN company_profile.signatory_title; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.company_profile.signatory_title IS 'Job title of the signatory (e.g. "Head of People").';


--
-- Name: company_profile_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.company_profile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.company_profile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: document_categories_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.document_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_categories; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.document_categories (
    id integer DEFAULT nextval('hrweb.document_categories_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    description text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE document_categories; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.document_categories IS 'Document categories. When a company has none, the API returns six built-in defaults.';


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.documents (
    id integer DEFAULT nextval('hrweb.documents_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    filename text NOT NULL,
    filesize integer NOT NULL,
    mime_type text NOT NULL,
    category_id integer,
    uploaded_by integer NOT NULL,
    uploaded_at timestamp without time zone DEFAULT now() NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    metadata jsonb,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    category text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE documents; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.documents IS 'Document metadata. The file is in bucket hrweb-documents at path filename. uploaded_by is the owning employee id; category is the free-text category the app shows.';


--
-- Name: employee_onboarding_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.employee_onboarding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_onboarding; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.employee_onboarding (
    id integer DEFAULT nextval('hrweb.employee_onboarding_id_seq'::regclass) NOT NULL,
    employee_id integer NOT NULL,
    step_id integer NOT NULL,
    status text DEFAULT 'not_started'::text NOT NULL,
    completed_at timestamp without time zone,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE employee_onboarding; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.employee_onboarding IS 'An employee''s progress on one onboarding step: status not_started / in_progress / completed, completed_at when completed. One row per person and step. When every step of the company is completed, hrweb-api sets employees.is_onboarded and onboarding_completed_at (never unset).';


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.employees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.employees (
    id integer DEFAULT nextval('hrweb.employees_id_seq'::regclass) NOT NULL,
    username text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text NOT NULL,
    company_email text,
    role text DEFAULT 'employee'::text NOT NULL,
    gender text,
    department text,
    "position" text,
    job_area text,
    avatar text,
    last_login timestamp without time zone,
    linkedin text,
    github text,
    behance text,
    dribbble text,
    twitter text,
    website text,
    pan_number text,
    aadhaar_number text,
    passport_number text,
    pf_number text,
    uan_number text,
    bank_account_number text,
    bank_name text,
    ifsc_code text,
    phone_number text,
    emergency_contact_name text,
    emergency_contact_number text,
    emergency_contact_relation text,
    current_address text,
    permanent_address text,
    city text,
    state text,
    country text,
    pincode text,
    employee_id text,
    joining_date timestamp without time zone,
    probation_end_date timestamp without time zone,
    employment_type text,
    work_location text,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    user_id uuid,
    is_onboarded boolean DEFAULT false NOT NULL,
    onboarding_completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE employees; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.employees IS 'Employee HR profile (job, contact, statutory and bank details). Login accounts are core.users.';


--
-- Name: COLUMN employees.role; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.employees.role IS 'Copy of the HRweb role (admin = hr, employee) for reports. The source of truth is core.tenant_members.role.';


--
-- Name: COLUMN employees.avatar; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.employees.avatar IS 'Profile picture URL (bucket hrweb-profile-pictures). The API returns it as both avatar and photoUrl.';


--
-- Name: COLUMN employees.user_id; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.employees.user_id IS 'Sign-in account (core.users.id = Supabase Auth user id). The API uses this uuid as the person''s id.';


--
-- Name: COLUMN employees.is_onboarded; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON COLUMN hrweb.employees.is_onboarded IS 'True once every onboarding step is completed.';


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.events (
    id integer DEFAULT nextval('hrweb.events_id_seq'::regclass) NOT NULL,
    title text NOT NULL,
    description text,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    location text,
    category text,
    created_by integer NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE events; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.events IS 'Company calendar events. category holds the event type (meeting, event, holiday...). created_by is the creating employee id (0 = imported).';


--
-- Name: generated_documents; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.generated_documents (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    template text NOT NULL,
    title text NOT NULL,
    employee_id integer,
    fields jsonb DEFAULT '{}'::jsonb NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_by_employee_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT generated_documents_fields_check CHECK ((jsonb_typeof(fields) = 'object'::text)),
    CONSTRAINT generated_documents_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'final'::text]))),
    CONSTRAINT generated_documents_title_check CHECK ((length(btrim(title)) > 0))
);


--
-- Name: TABLE generated_documents; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.generated_documents IS 'Document Generator: one generated document. template is the template title from the app (src/config/document-generator.ts); fields are the values typed into the form; content is the rendered plain text. employee_id is the employee the document is about (NULL when it is about an outside party, e.g. an NDA). The creator and the employee it is about may read it; the creator or HR edit / delete; HR sees all.';


--
-- Name: generated_documents_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.generated_documents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.generated_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: integration_webhooks; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.integration_webhooks (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    events text[] DEFAULT '{}'::text[] NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by_employee_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE integration_webhooks; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.integration_webhooks IS 'Outgoing webhooks configured by HR on the Integrations page (was app_data "webhook:").';


--
-- Name: integration_webhooks_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.integration_webhooks ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.integration_webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: key_task_progress; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.key_task_progress (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    key_task_id bigint NOT NULL,
    employee_id integer NOT NULL,
    status text DEFAULT 'in_progress'::text NOT NULL,
    rating numeric(2,1),
    platform text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT key_task_progress_rating_check CHECK (((rating >= (1)::numeric) AND (rating <= (5)::numeric))),
    CONSTRAINT key_task_progress_status_check CHECK ((status = ANY (ARRAY['in_progress'::text, 'completed'::text])))
);


--
-- Name: TABLE key_task_progress; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.key_task_progress IS 'One employee''s progress on one key task: in_progress after "Start Review", completed with the rating (1-5) they gave. No row = pending. Feeds the Review Stats card.';


--
-- Name: key_task_progress_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.key_task_progress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.key_task_progress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: key_tasks; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.key_tasks (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    platform text DEFAULT ''::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    due_date date,
    assignee_employee_id integer,
    status text DEFAULT 'active'::text NOT NULL,
    created_by_employee_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT key_tasks_priority_check CHECK ((priority = ANY (ARRAY['high'::text, 'medium'::text, 'low'::text]))),
    CONSTRAINT key_tasks_status_check CHECK ((status = ANY (ARRAY['active'::text, 'archived'::text]))),
    CONSTRAINT key_tasks_title_check CHECK ((length(btrim(title)) > 0))
);


--
-- Name: TABLE key_tasks; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.key_tasks IS 'Key Tasks screen: review tasks set by HR. platform is the review platform name shown in the app (Glassdoor, Google, Indeed, LinkedIn, AmbitionBox). assignee_employee_id NULL = everyone in the company. HR writes; employees read the tasks assigned to them or to everyone.';


--
-- Name: key_tasks_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.key_tasks ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.key_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notifications; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.notifications (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    employee_id integer NOT NULL,
    title text NOT NULL,
    message text DEFAULT ''::text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    action_url text,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notifications_type_check CHECK ((type = ANY (ARRAY['info'::text, 'success'::text, 'warning'::text, 'error'::text])))
);


--
-- Name: TABLE notifications; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.notifications IS 'In-app notifications for one employee (was app_data "notification:").';


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.notifications ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: onboarding_steps_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.onboarding_steps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: onboarding_steps; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.onboarding_steps (
    id integer DEFAULT nextval('hrweb.onboarding_steps_id_seq'::regclass) NOT NULL,
    name text NOT NULL,
    description text,
    "order" integer NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE onboarding_steps; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.onboarding_steps IS 'Onboarding step definitions per company, in display order ("order", 1 = first). HR manages them on the Onboarding screen; a company with none can insert the standard steps from the app (src/config/onboarding.ts) in one click. Deleting a step deletes everyone''s progress on it (done by hrweb-api).';


--
-- Name: performance_reviews; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.performance_reviews (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    employee_id integer NOT NULL,
    reviewer_employee_id integer,
    period text NOT NULL,
    overall_rating numeric(3,1) DEFAULT 0 NOT NULL,
    strengths text DEFAULT ''::text NOT NULL,
    areas_for_improvement text DEFAULT ''::text NOT NULL,
    goals jsonb DEFAULT '[]'::jsonb NOT NULL,
    comments text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT performance_reviews_overall_rating_check CHECK (((overall_rating >= (0)::numeric) AND (overall_rating <= (5)::numeric)))
);


--
-- Name: TABLE performance_reviews; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.performance_reviews IS 'Performance reviews written by HR (was app_data "review:"). The reviewed employee may read their own.';


--
-- Name: performance_reviews_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.performance_reviews ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.performance_reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: report_dashboards_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.report_dashboards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_dashboards; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.report_dashboards (
    id integer DEFAULT nextval('hrweb.report_dashboards_id_seq'::regclass) NOT NULL,
    employee_id integer NOT NULL,
    name text NOT NULL,
    layout jsonb NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: salary_slips; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.salary_slips (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    employee_id integer NOT NULL,
    month text NOT NULL,
    year integer NOT NULL,
    basic_salary numeric(14,2) NOT NULL,
    allowances jsonb DEFAULT '[]'::jsonb NOT NULL,
    deductions jsonb DEFAULT '[]'::jsonb NOT NULL,
    gross_salary numeric(14,2) NOT NULL,
    net_salary numeric(14,2) NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE salary_slips; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.salary_slips IS 'Monthly salary slips (was app_data "salary_slip:"). PERSONAL: only the employee (read) and HR (read/write) may see them. allowances / deductions are [{name, amount}].';


--
-- Name: salary_slips_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.salary_slips ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.salary_slips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: time_off_balances_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

CREATE SEQUENCE hrweb.time_off_balances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_off_balances; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.time_off_balances (
    id integer DEFAULT nextval('hrweb.time_off_balances_id_seq'::regclass) NOT NULL,
    employee_id integer NOT NULL,
    vacation_total integer DEFAULT 20 NOT NULL,
    vacation_used integer DEFAULT 0 NOT NULL,
    sick_total integer DEFAULT 10 NOT NULL,
    sick_used integer DEFAULT 0 NOT NULL,
    personal_total integer DEFAULT 5 NOT NULL,
    personal_used integer DEFAULT 0 NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE time_off_balances; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.time_off_balances IS 'Leave balance per employee (days): vacation, sick and personal totals and days used. Created on first read (20 / 10 / 5).';


--
-- Name: time_off_requests; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.time_off_requests (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    employee_id integer NOT NULL,
    type text NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    days integer NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    approved_by_employee_id integer,
    approved_at timestamp with time zone,
    rejected_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT time_off_requests_check CHECK ((end_date >= start_date)),
    CONSTRAINT time_off_requests_days_check CHECK ((days > 0)),
    CONSTRAINT time_off_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text, 'cancelled'::text]))),
    CONSTRAINT time_off_requests_type_check CHECK ((type = ANY (ARRAY['vacation'::text, 'sick'::text, 'personal'::text])))
);


--
-- Name: TABLE time_off_requests; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.time_off_requests IS 'Leave requests (was app_data "time_off_request:"). HR approves or rejects; approval adds the days to time_off_balances.';


--
-- Name: time_off_requests_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.time_off_requests ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.time_off_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: training_courses; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.training_courses (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    category text NOT NULL,
    duration numeric(8,2) DEFAULT 0 NOT NULL,
    instructor text DEFAULT ''::text NOT NULL,
    objectives jsonb DEFAULT '[]'::jsonb NOT NULL,
    materials jsonb DEFAULT '[]'::jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE training_courses; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.training_courses IS 'Training courses (was app_data "training:"). category: technical, leadership, compliance, soft-skills, onboarding; duration in hours.';


--
-- Name: training_courses_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.training_courses ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.training_courses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: training_enrollments; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.training_enrollments (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    employee_id integer NOT NULL,
    training_course_id bigint NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'in_progress'::text NOT NULL,
    enrolled_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT training_enrollments_progress_check CHECK (((progress >= 0) AND (progress <= 100)))
);


--
-- Name: TABLE training_enrollments; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.training_enrollments IS 'An employee''s enrolment and progress (0-100) in a training course (was app_data "training_enrollment:").';


--
-- Name: training_enrollments_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.training_enrollments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.training_enrollments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_preferences; Type: TABLE; Schema: hrweb; Owner: -
--

CREATE TABLE hrweb.user_preferences (
    id bigint NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL,
    employee_id integer NOT NULL,
    email_notifications boolean DEFAULT true NOT NULL,
    push_notifications boolean DEFAULT false NOT NULL,
    weekly_reports boolean DEFAULT true NOT NULL,
    task_reminders boolean DEFAULT true NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    timezone text DEFAULT 'Asia/Kolkata'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_preferences; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON TABLE hrweb.user_preferences IS 'Settings screen: one row per person and company (notification switches, language code, IANA timezone). No row = the defaults; created on first save. Only the person themself or HR. Passwords are not here: they belong to Supabase Auth.';


--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.user_preferences ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME hrweb.user_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: app_data; Type: TABLE; Schema: stayweb; Owner: -
--

CREATE TABLE stayweb.app_data (
    key text NOT NULL,
    value jsonb NOT NULL,
    tenant_id uuid DEFAULT '00000000-0000-0000-0000-000000000001'::uuid NOT NULL
);


--
-- Name: TABLE app_data; Type: COMMENT; Schema: stayweb; Owner: -
--

COMMENT ON TABLE stayweb.app_data IS 'Stayweb records as key -> JSON. Keys look like <tenant>:<record type>:<id> (e.g. :booking:, :room-inventory:).';


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (product, key);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: tenant_members tenant_members_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_pkey PRIMARY KEY (tenant_id, user_id, product);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: attestations attestations_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.attestations
    ADD CONSTRAINT attestations_pkey PRIMARY KEY (id);


--
-- Name: blockchain_proofs blockchain_proofs_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_proofs
    ADD CONSTRAINT blockchain_proofs_pkey PRIMARY KEY (id);


--
-- Name: blockchain_transactions blockchain_transactions_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_pkey PRIMARY KEY (id);


--
-- Name: blockchain_transactions blockchain_transactions_transaction_hash_key; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_transaction_hash_key UNIQUE (transaction_hash);


--
-- Name: credential_attributes credential_attributes_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_attributes
    ADD CONSTRAINT credential_attributes_pkey PRIMARY KEY (id);


--
-- Name: credential_history credential_history_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_history
    ADD CONSTRAINT credential_history_pkey PRIMARY KEY (id);


--
-- Name: credential_metrics credential_metrics_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_metrics
    ADD CONSTRAINT credential_metrics_pkey PRIMARY KEY (id);


--
-- Name: credential_schemas credential_schemas_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_schemas
    ADD CONSTRAINT credential_schemas_pkey PRIMARY KEY (id);


--
-- Name: credential_subjects credential_subjects_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_subjects
    ADD CONSTRAINT credential_subjects_pkey PRIMARY KEY (id);


--
-- Name: credentials credentials_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_pkey PRIMARY KEY (id);


--
-- Name: did_entities did_entities_did_key; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_entities
    ADD CONSTRAINT did_entities_did_key UNIQUE (did);


--
-- Name: did_entities did_entities_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_entities
    ADD CONSTRAINT did_entities_pkey PRIMARY KEY (id);


--
-- Name: did_keys did_keys_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_keys
    ADD CONSTRAINT did_keys_pkey PRIMARY KEY (id);


--
-- Name: document_audit_log document_audit_log_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_audit_log
    ADD CONSTRAINT document_audit_log_pkey PRIMARY KEY (id);


--
-- Name: document_folders document_folders_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_folders
    ADD CONSTRAINT document_folders_pkey PRIMARY KEY (id);


--
-- Name: document_folders document_folders_tenant_id_id_key; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_folders
    ADD CONSTRAINT document_folders_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: document_shares document_shares_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_shares
    ADD CONSTRAINT document_shares_pkey PRIMARY KEY (id);


--
-- Name: document_signatures document_signatures_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signatures
    ADD CONSTRAINT document_signatures_pkey PRIMARY KEY (id);


--
-- Name: document_signers document_signers_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signers
    ADD CONSTRAINT document_signers_pkey PRIMARY KEY (id);


--
-- Name: document_stars document_stars_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_stars
    ADD CONSTRAINT document_stars_pkey PRIMARY KEY (document_id, user_id);


--
-- Name: document_versions document_versions_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_versions
    ADD CONSTRAINT document_versions_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: documents documents_tenant_id_id_key; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.documents
    ADD CONSTRAINT documents_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: integration_events integration_events_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integration_events
    ADD CONSTRAINT integration_events_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: product_certificates product_certificates_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_certificates
    ADD CONSTRAINT product_certificates_pkey PRIMARY KEY (id);


--
-- Name: product_qr_codes product_qr_codes_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_qr_codes
    ADD CONSTRAINT product_qr_codes_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: qr_scans qr_scans_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.qr_scans
    ADD CONSTRAINT qr_scans_pkey PRIMARY KEY (id);


--
-- Name: schema_attributes schema_attributes_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.schema_attributes
    ADD CONSTRAINT schema_attributes_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: template_elements template_elements_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.template_elements
    ADD CONSTRAINT template_elements_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (tenant_id);


--
-- Name: verification_requests verification_requests_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_requests
    ADD CONSTRAINT verification_requests_pkey PRIMARY KEY (id);


--
-- Name: verification_results verification_results_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_results
    ADD CONSTRAINT verification_results_pkey PRIMARY KEY (id);


--
-- Name: warranties warranties_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranties
    ADD CONSTRAINT warranties_pkey PRIMARY KEY (id);


--
-- Name: warranty_claims warranty_claims_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranty_claims
    ADD CONSTRAINT warranty_claims_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: app_data app_data_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.app_data
    ADD CONSTRAINT app_data_pkey PRIMARY KEY (key);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: benefit_enrollments benefit_enrollments_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.benefit_enrollments
    ADD CONSTRAINT benefit_enrollments_pkey PRIMARY KEY (id);


--
-- Name: benefits benefits_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.benefits
    ADD CONSTRAINT benefits_pkey PRIMARY KEY (id);


--
-- Name: company_profile company_profile_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.company_profile
    ADD CONSTRAINT company_profile_pkey PRIMARY KEY (id);


--
-- Name: company_profile company_profile_tenant_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.company_profile
    ADD CONSTRAINT company_profile_tenant_key UNIQUE (tenant_id);


--
-- Name: document_categories document_categories_name_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.document_categories
    ADD CONSTRAINT document_categories_name_key UNIQUE (name);


--
-- Name: document_categories document_categories_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.document_categories
    ADD CONSTRAINT document_categories_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: employee_onboarding employee_onboarding_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_pkey PRIMARY KEY (id);


--
-- Name: employee_onboarding employee_onboarding_tenant_employee_step_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_tenant_employee_step_key UNIQUE (tenant_id, employee_id, step_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: employees employees_tenant_email_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_tenant_email_key UNIQUE (tenant_id, email);


--
-- Name: CONSTRAINT employees_tenant_email_key ON employees; Type: COMMENT; Schema: hrweb; Owner: -
--

COMMENT ON CONSTRAINT employees_tenant_email_key ON hrweb.employees IS 'An email has at most one HR profile per company; the same person may work for several companies.';


--
-- Name: employees employees_tenant_username_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_tenant_username_key UNIQUE (tenant_id, username);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: generated_documents generated_documents_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.generated_documents
    ADD CONSTRAINT generated_documents_pkey PRIMARY KEY (id);


--
-- Name: integration_webhooks integration_webhooks_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.integration_webhooks
    ADD CONSTRAINT integration_webhooks_pkey PRIMARY KEY (id);


--
-- Name: key_task_progress key_task_progress_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_task_progress
    ADD CONSTRAINT key_task_progress_pkey PRIMARY KEY (id);


--
-- Name: key_task_progress key_task_progress_task_employee_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_task_progress
    ADD CONSTRAINT key_task_progress_task_employee_key UNIQUE (tenant_id, key_task_id, employee_id);


--
-- Name: key_tasks key_tasks_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_tasks
    ADD CONSTRAINT key_tasks_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: onboarding_steps onboarding_steps_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.onboarding_steps
    ADD CONSTRAINT onboarding_steps_pkey PRIMARY KEY (id);


--
-- Name: performance_reviews performance_reviews_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.performance_reviews
    ADD CONSTRAINT performance_reviews_pkey PRIMARY KEY (id);


--
-- Name: report_dashboards report_dashboards_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.report_dashboards
    ADD CONSTRAINT report_dashboards_pkey PRIMARY KEY (id);


--
-- Name: salary_slips salary_slips_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.salary_slips
    ADD CONSTRAINT salary_slips_pkey PRIMARY KEY (id);


--
-- Name: time_off_balances time_off_balances_employee_id_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_balances
    ADD CONSTRAINT time_off_balances_employee_id_key UNIQUE (employee_id);


--
-- Name: time_off_balances time_off_balances_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_balances
    ADD CONSTRAINT time_off_balances_pkey PRIMARY KEY (id);


--
-- Name: time_off_requests time_off_requests_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_requests
    ADD CONSTRAINT time_off_requests_pkey PRIMARY KEY (id);


--
-- Name: training_courses training_courses_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.training_courses
    ADD CONSTRAINT training_courses_pkey PRIMARY KEY (id);


--
-- Name: training_enrollments training_enrollments_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.training_enrollments
    ADD CONSTRAINT training_enrollments_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_tenant_employee_key; Type: CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.user_preferences
    ADD CONSTRAINT user_preferences_tenant_employee_key UNIQUE (tenant_id, employee_id);


--
-- Name: app_data app_data_pkey; Type: CONSTRAINT; Schema: stayweb; Owner: -
--

ALTER TABLE ONLY stayweb.app_data
    ADD CONSTRAINT app_data_pkey PRIMARY KEY (key);


--
-- Name: audit_log_tenant_at_idx; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX audit_log_tenant_at_idx ON core.audit_log USING btree (tenant_id, at DESC);


--
-- Name: sessions_user_idx; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX sessions_user_idx ON core.sessions USING btree (user_id);


--
-- Name: tenant_members_user_idx; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX tenant_members_user_idx ON core.tenant_members USING btree (user_id);


--
-- Name: activity_logs_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX activity_logs_tenant_idx ON docweb.activity_logs USING btree (tenant_id);


--
-- Name: analytics_events_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX analytics_events_tenant_idx ON docweb.analytics_events USING btree (tenant_id);


--
-- Name: api_keys_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX api_keys_tenant_idx ON docweb.api_keys USING btree (tenant_id);


--
-- Name: attestations_hash_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX attestations_hash_idx ON docweb.attestations USING btree (document_hash);


--
-- Name: attestations_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX attestations_tenant_idx ON docweb.attestations USING btree (tenant_id, attested_at DESC);


--
-- Name: blockchain_proofs_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX blockchain_proofs_tenant_idx ON docweb.blockchain_proofs USING btree (tenant_id);


--
-- Name: blockchain_transactions_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX blockchain_transactions_tenant_idx ON docweb.blockchain_transactions USING btree (tenant_id);


--
-- Name: credential_attributes_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_attributes_tenant_idx ON docweb.credential_attributes USING btree (tenant_id);


--
-- Name: credential_history_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_history_tenant_idx ON docweb.credential_history USING btree (tenant_id);


--
-- Name: credential_metrics_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_metrics_tenant_idx ON docweb.credential_metrics USING btree (tenant_id);


--
-- Name: credential_schemas_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_schemas_tenant_idx ON docweb.credential_schemas USING btree (tenant_id);


--
-- Name: credential_subjects_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credential_subjects_tenant_idx ON docweb.credential_subjects USING btree (tenant_id);


--
-- Name: credentials_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX credentials_tenant_idx ON docweb.credentials USING btree (tenant_id);


--
-- Name: did_entities_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX did_entities_tenant_idx ON docweb.did_entities USING btree (tenant_id);


--
-- Name: did_keys_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX did_keys_tenant_idx ON docweb.did_keys USING btree (tenant_id);


--
-- Name: document_audit_log_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_audit_log_tenant_idx ON docweb.document_audit_log USING btree (tenant_id);


--
-- Name: document_folders_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_folders_tenant_idx ON docweb.document_folders USING btree (tenant_id);


--
-- Name: document_folders_tenant_name_key; Type: INDEX; Schema: docweb; Owner: -
--

CREATE UNIQUE INDEX document_folders_tenant_name_key ON docweb.document_folders USING btree (tenant_id, lower(btrim(name)));


--
-- Name: document_shares_document_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_shares_document_idx ON docweb.document_shares USING btree (document_id);


--
-- Name: document_shares_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_shares_tenant_idx ON docweb.document_shares USING btree (tenant_id);


--
-- Name: document_signatures_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_signatures_tenant_idx ON docweb.document_signatures USING btree (tenant_id);


--
-- Name: document_signers_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_signers_tenant_idx ON docweb.document_signers USING btree (tenant_id);


--
-- Name: document_stars_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_stars_tenant_idx ON docweb.document_stars USING btree (tenant_id);


--
-- Name: document_versions_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX document_versions_tenant_idx ON docweb.document_versions USING btree (tenant_id);


--
-- Name: documents_folder_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX documents_folder_idx ON docweb.documents USING btree (folder_id);


--
-- Name: documents_sha256_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX documents_sha256_idx ON docweb.documents USING btree (lower(sha256_hash));


--
-- Name: documents_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX documents_tenant_idx ON docweb.documents USING btree (tenant_id);


--
-- Name: idx_activity_logs_user; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_activity_logs_user ON docweb.activity_logs USING btree (user_id);


--
-- Name: idx_blockchain_tx_cred; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_blockchain_tx_cred ON docweb.blockchain_transactions USING btree (credential_id);


--
-- Name: idx_credential_history_cred; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_credential_history_cred ON docweb.credential_history USING btree (credential_id);


--
-- Name: idx_credentials_issuer; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_credentials_issuer ON docweb.credentials USING btree (issuer_id);


--
-- Name: idx_credentials_schema; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_credentials_schema ON docweb.credentials USING btree (schema_id);


--
-- Name: idx_credentials_status; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_credentials_status ON docweb.credentials USING btree (status);


--
-- Name: idx_documents_status; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_documents_status ON docweb.documents USING btree (status);


--
-- Name: idx_notifications_status; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_notifications_status ON docweb.notifications USING btree (status);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_notifications_user ON docweb.notifications USING btree (user_id);


--
-- Name: idx_qr_scans_qr; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_qr_scans_qr ON docweb.qr_scans USING btree (qr_code_id);


--
-- Name: idx_verification_req_cred; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX idx_verification_req_cred ON docweb.verification_requests USING btree (credential_id);


--
-- Name: integration_events_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX integration_events_tenant_idx ON docweb.integration_events USING btree (tenant_id);


--
-- Name: integrations_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX integrations_tenant_idx ON docweb.integrations USING btree (tenant_id);


--
-- Name: invoices_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX invoices_tenant_idx ON docweb.invoices USING btree (tenant_id);


--
-- Name: notifications_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX notifications_tenant_idx ON docweb.notifications USING btree (tenant_id);


--
-- Name: product_certificates_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX product_certificates_tenant_idx ON docweb.product_certificates USING btree (tenant_id);


--
-- Name: product_qr_codes_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX product_qr_codes_tenant_idx ON docweb.product_qr_codes USING btree (tenant_id);


--
-- Name: products_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX products_tenant_idx ON docweb.products USING btree (tenant_id);


--
-- Name: qr_scans_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX qr_scans_tenant_idx ON docweb.qr_scans USING btree (tenant_id);


--
-- Name: schema_attributes_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX schema_attributes_tenant_idx ON docweb.schema_attributes USING btree (tenant_id);


--
-- Name: subscription_plans_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX subscription_plans_tenant_idx ON docweb.subscription_plans USING btree (tenant_id);


--
-- Name: subscriptions_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX subscriptions_tenant_idx ON docweb.subscriptions USING btree (tenant_id);


--
-- Name: system_logs_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX system_logs_tenant_idx ON docweb.system_logs USING btree (tenant_id);


--
-- Name: template_elements_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX template_elements_tenant_idx ON docweb.template_elements USING btree (tenant_id);


--
-- Name: templates_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX templates_tenant_idx ON docweb.templates USING btree (tenant_id);


--
-- Name: tenant_settings_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX tenant_settings_tenant_idx ON docweb.tenant_settings USING btree (tenant_id);


--
-- Name: verification_requests_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX verification_requests_tenant_idx ON docweb.verification_requests USING btree (tenant_id);


--
-- Name: verification_results_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX verification_results_tenant_idx ON docweb.verification_results USING btree (tenant_id);


--
-- Name: warranties_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX warranties_tenant_idx ON docweb.warranties USING btree (tenant_id);


--
-- Name: warranty_claims_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX warranty_claims_tenant_idx ON docweb.warranty_claims USING btree (tenant_id);


--
-- Name: webhook_events_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX webhook_events_tenant_idx ON docweb.webhook_events USING btree (tenant_id);


--
-- Name: webhooks_tenant_idx; Type: INDEX; Schema: docweb; Owner: -
--

CREATE INDEX webhooks_tenant_idx ON docweb.webhooks USING btree (tenant_id);


--
-- Name: announcements_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX announcements_tenant_idx ON hrweb.announcements USING btree (tenant_id);


--
-- Name: app_data_key_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX app_data_key_idx ON hrweb.app_data USING btree (key text_pattern_ops);


--
-- Name: app_data_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX app_data_tenant_idx ON hrweb.app_data USING btree (tenant_id);


--
-- Name: articles_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX articles_tenant_idx ON hrweb.articles USING btree (tenant_id);


--
-- Name: benefit_enrollments_benefit_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX benefit_enrollments_benefit_idx ON hrweb.benefit_enrollments USING btree (benefit_id);


--
-- Name: benefit_enrollments_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX benefit_enrollments_employee_idx ON hrweb.benefit_enrollments USING btree (employee_id);


--
-- Name: benefit_enrollments_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX benefit_enrollments_tenant_idx ON hrweb.benefit_enrollments USING btree (tenant_id);


--
-- Name: benefits_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX benefits_tenant_idx ON hrweb.benefits USING btree (tenant_id);


--
-- Name: company_profile_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX company_profile_tenant_idx ON hrweb.company_profile USING btree (tenant_id);


--
-- Name: document_categories_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX document_categories_tenant_idx ON hrweb.document_categories USING btree (tenant_id);


--
-- Name: documents_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX documents_tenant_idx ON hrweb.documents USING btree (tenant_id);


--
-- Name: documents_uploaded_by_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX documents_uploaded_by_idx ON hrweb.documents USING btree (uploaded_by);


--
-- Name: employee_onboarding_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX employee_onboarding_employee_idx ON hrweb.employee_onboarding USING btree (employee_id);


--
-- Name: employee_onboarding_step_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX employee_onboarding_step_idx ON hrweb.employee_onboarding USING btree (step_id);


--
-- Name: employee_onboarding_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX employee_onboarding_tenant_idx ON hrweb.employee_onboarding USING btree (tenant_id);


--
-- Name: employees_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX employees_tenant_idx ON hrweb.employees USING btree (tenant_id);


--
-- Name: employees_tenant_user_key; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE UNIQUE INDEX employees_tenant_user_key ON hrweb.employees USING btree (tenant_id, user_id) WHERE (user_id IS NOT NULL);


--
-- Name: employees_user_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX employees_user_idx ON hrweb.employees USING btree (user_id);


--
-- Name: events_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX events_tenant_idx ON hrweb.events USING btree (tenant_id);


--
-- Name: generated_documents_creator_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX generated_documents_creator_idx ON hrweb.generated_documents USING btree (created_by_employee_id);


--
-- Name: generated_documents_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX generated_documents_employee_idx ON hrweb.generated_documents USING btree (employee_id);


--
-- Name: generated_documents_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX generated_documents_tenant_idx ON hrweb.generated_documents USING btree (tenant_id);


--
-- Name: integration_webhooks_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX integration_webhooks_tenant_idx ON hrweb.integration_webhooks USING btree (tenant_id);


--
-- Name: key_task_progress_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX key_task_progress_employee_idx ON hrweb.key_task_progress USING btree (employee_id);


--
-- Name: key_task_progress_task_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX key_task_progress_task_idx ON hrweb.key_task_progress USING btree (key_task_id);


--
-- Name: key_task_progress_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX key_task_progress_tenant_idx ON hrweb.key_task_progress USING btree (tenant_id);


--
-- Name: key_tasks_assignee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX key_tasks_assignee_idx ON hrweb.key_tasks USING btree (assignee_employee_id);


--
-- Name: key_tasks_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX key_tasks_tenant_idx ON hrweb.key_tasks USING btree (tenant_id);


--
-- Name: notifications_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX notifications_employee_idx ON hrweb.notifications USING btree (employee_id);


--
-- Name: notifications_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX notifications_tenant_idx ON hrweb.notifications USING btree (tenant_id);


--
-- Name: onboarding_steps_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX onboarding_steps_tenant_idx ON hrweb.onboarding_steps USING btree (tenant_id);


--
-- Name: performance_reviews_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX performance_reviews_employee_idx ON hrweb.performance_reviews USING btree (employee_id);


--
-- Name: performance_reviews_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX performance_reviews_tenant_idx ON hrweb.performance_reviews USING btree (tenant_id);


--
-- Name: report_dashboards_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX report_dashboards_tenant_idx ON hrweb.report_dashboards USING btree (tenant_id);


--
-- Name: salary_slips_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX salary_slips_employee_idx ON hrweb.salary_slips USING btree (employee_id);


--
-- Name: salary_slips_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX salary_slips_tenant_idx ON hrweb.salary_slips USING btree (tenant_id);


--
-- Name: time_off_balances_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX time_off_balances_tenant_idx ON hrweb.time_off_balances USING btree (tenant_id);


--
-- Name: time_off_requests_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX time_off_requests_employee_idx ON hrweb.time_off_requests USING btree (employee_id);


--
-- Name: time_off_requests_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX time_off_requests_tenant_idx ON hrweb.time_off_requests USING btree (tenant_id);


--
-- Name: training_courses_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX training_courses_tenant_idx ON hrweb.training_courses USING btree (tenant_id);


--
-- Name: training_enrollments_course_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX training_enrollments_course_idx ON hrweb.training_enrollments USING btree (training_course_id);


--
-- Name: training_enrollments_employee_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX training_enrollments_employee_idx ON hrweb.training_enrollments USING btree (employee_id);


--
-- Name: training_enrollments_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX training_enrollments_tenant_idx ON hrweb.training_enrollments USING btree (tenant_id);


--
-- Name: user_preferences_tenant_idx; Type: INDEX; Schema: hrweb; Owner: -
--

CREATE INDEX user_preferences_tenant_idx ON hrweb.user_preferences USING btree (tenant_id);


--
-- Name: app_data_key_idx; Type: INDEX; Schema: stayweb; Owner: -
--

CREATE INDEX app_data_key_idx ON stayweb.app_data USING btree (key text_pattern_ops);


--
-- Name: app_data_tenant_idx; Type: INDEX; Schema: stayweb; Owner: -
--

CREATE INDEX app_data_tenant_idx ON stayweb.app_data USING btree (tenant_id);


--
-- Name: announcements set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.announcements FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: articles set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.articles FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: benefit_enrollments set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.benefit_enrollments FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: benefits set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.benefits FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: company_profile set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.company_profile FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: document_categories set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.document_categories FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: documents set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.documents FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: employee_onboarding set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.employee_onboarding FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: employees set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.employees FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: events set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.events FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: generated_documents set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.generated_documents FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: integration_webhooks set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.integration_webhooks FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: key_task_progress set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.key_task_progress FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: key_tasks set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.key_tasks FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: notifications set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.notifications FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: onboarding_steps set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.onboarding_steps FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: performance_reviews set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.performance_reviews FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: salary_slips set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.salary_slips FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: time_off_balances set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.time_off_balances FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: time_off_requests set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.time_off_requests FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: training_courses set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.training_courses FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: training_enrollments set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.training_enrollments FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: user_preferences set_updated_at; Type: TRIGGER; Schema: hrweb; Owner: -
--

CREATE TRIGGER set_updated_at BEFORE UPDATE ON hrweb.user_preferences FOR EACH ROW EXECUTE FUNCTION hrweb.set_updated_at();


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: sessions sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sessions
    ADD CONSTRAINT sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tenant_members tenant_members_invited_by_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: tenant_members tenant_members_product_role_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_product_role_fkey FOREIGN KEY (product, role) REFERENCES core.roles(product, key);


--
-- Name: tenant_members tenant_members_tenant_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_members tenant_members_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.tenant_members
    ADD CONSTRAINT tenant_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.activity_logs
    ADD CONSTRAINT activity_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: analytics_events analytics_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.analytics_events
    ADD CONSTRAINT analytics_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: analytics_events analytics_events_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.analytics_events
    ADD CONSTRAINT analytics_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: api_keys api_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.api_keys
    ADD CONSTRAINT api_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: attestations attestations_attested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.attestations
    ADD CONSTRAINT attestations_attested_by_user_id_fkey FOREIGN KEY (attested_by_user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: attestations attestations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.attestations
    ADD CONSTRAINT attestations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: blockchain_proofs blockchain_proofs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_proofs
    ADD CONSTRAINT blockchain_proofs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: blockchain_proofs blockchain_proofs_transaction_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_proofs
    ADD CONSTRAINT blockchain_proofs_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES docweb.blockchain_transactions(id) ON DELETE CASCADE;


--
-- Name: blockchain_transactions blockchain_transactions_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id);


--
-- Name: blockchain_transactions blockchain_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_attributes credential_attributes_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_attributes
    ADD CONSTRAINT credential_attributes_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_attributes credential_attributes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_attributes
    ADD CONSTRAINT credential_attributes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_history credential_history_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_history
    ADD CONSTRAINT credential_history_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_history credential_history_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_history
    ADD CONSTRAINT credential_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_metrics credential_metrics_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_metrics
    ADD CONSTRAINT credential_metrics_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_metrics credential_metrics_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_metrics
    ADD CONSTRAINT credential_metrics_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_schemas credential_schemas_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_schemas
    ADD CONSTRAINT credential_schemas_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credential_subjects credential_subjects_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_subjects
    ADD CONSTRAINT credential_subjects_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id) ON DELETE CASCADE;


--
-- Name: credential_subjects credential_subjects_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credential_subjects
    ADD CONSTRAINT credential_subjects_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: credentials credentials_issuer_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_issuer_id_fkey FOREIGN KEY (issuer_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: credentials credentials_schema_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES docweb.credential_schemas(id);


--
-- Name: credentials credentials_template_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_template_id_fkey FOREIGN KEY (template_id) REFERENCES docweb.templates(id);


--
-- Name: credentials credentials_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.credentials
    ADD CONSTRAINT credentials_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: did_entities did_entities_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_entities
    ADD CONSTRAINT did_entities_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: did_keys did_keys_did_entity_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_keys
    ADD CONSTRAINT did_keys_did_entity_id_fkey FOREIGN KEY (did_entity_id) REFERENCES docweb.did_entities(id) ON DELETE CASCADE;


--
-- Name: did_keys did_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.did_keys
    ADD CONSTRAINT did_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_audit_log document_audit_log_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_audit_log
    ADD CONSTRAINT document_audit_log_document_id_fkey FOREIGN KEY (document_id) REFERENCES docweb.documents(id) ON DELETE CASCADE;


--
-- Name: document_audit_log document_audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_audit_log
    ADD CONSTRAINT document_audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_audit_log document_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_audit_log
    ADD CONSTRAINT document_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: document_folders document_folders_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_folders
    ADD CONSTRAINT document_folders_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES core.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: document_folders document_folders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_folders
    ADD CONSTRAINT document_folders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: document_shares document_shares_shared_by_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_shares
    ADD CONSTRAINT document_shares_shared_by_user_id_fkey FOREIGN KEY (shared_by_user_id) REFERENCES core.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: document_shares document_shares_tenant_id_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_shares
    ADD CONSTRAINT document_shares_tenant_id_document_id_fkey FOREIGN KEY (tenant_id, document_id) REFERENCES docweb.documents(tenant_id, id) ON DELETE CASCADE;


--
-- Name: document_shares document_shares_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_shares
    ADD CONSTRAINT document_shares_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: document_signatures document_signatures_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signatures
    ADD CONSTRAINT document_signatures_document_id_fkey FOREIGN KEY (document_id) REFERENCES docweb.documents(id) ON DELETE CASCADE;


--
-- Name: document_signatures document_signatures_signer_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signatures
    ADD CONSTRAINT document_signatures_signer_id_fkey FOREIGN KEY (signer_id) REFERENCES docweb.document_signers(id);


--
-- Name: document_signatures document_signatures_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signatures
    ADD CONSTRAINT document_signatures_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_signers document_signers_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signers
    ADD CONSTRAINT document_signers_document_id_fkey FOREIGN KEY (document_id) REFERENCES docweb.documents(id) ON DELETE CASCADE;


--
-- Name: document_signers document_signers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signers
    ADD CONSTRAINT document_signers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_signers document_signers_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_signers
    ADD CONSTRAINT document_signers_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: document_stars document_stars_tenant_id_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_stars
    ADD CONSTRAINT document_stars_tenant_id_document_id_fkey FOREIGN KEY (tenant_id, document_id) REFERENCES docweb.documents(tenant_id, id) ON DELETE CASCADE;


--
-- Name: document_stars document_stars_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_stars
    ADD CONSTRAINT document_stars_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: document_stars document_stars_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_stars
    ADD CONSTRAINT document_stars_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_versions document_versions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_versions
    ADD CONSTRAINT document_versions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: document_versions document_versions_document_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_versions
    ADD CONSTRAINT document_versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES docweb.documents(id) ON DELETE CASCADE;


--
-- Name: document_versions document_versions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.document_versions
    ADD CONSTRAINT document_versions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: documents documents_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.documents
    ADD CONSTRAINT documents_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: documents documents_folder_fk; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.documents
    ADD CONSTRAINT documents_folder_fk FOREIGN KEY (tenant_id, folder_id) REFERENCES docweb.document_folders(tenant_id, id) ON DELETE SET NULL (folder_id);


--
-- Name: documents documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.documents
    ADD CONSTRAINT documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: integration_events integration_events_integration_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integration_events
    ADD CONSTRAINT integration_events_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES docweb.integrations(id) ON DELETE CASCADE;


--
-- Name: integration_events integration_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integration_events
    ADD CONSTRAINT integration_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: integrations integrations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.integrations
    ADD CONSTRAINT integrations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: invoices invoices_subscription_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.invoices
    ADD CONSTRAINT invoices_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES docweb.subscriptions(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.invoices
    ADD CONSTRAINT invoices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: notifications notifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.notifications
    ADD CONSTRAINT notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_certificates product_certificates_product_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_certificates
    ADD CONSTRAINT product_certificates_product_id_fkey FOREIGN KEY (product_id) REFERENCES docweb.products(id) ON DELETE CASCADE;


--
-- Name: product_certificates product_certificates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_certificates
    ADD CONSTRAINT product_certificates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: product_qr_codes product_qr_codes_product_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_qr_codes
    ADD CONSTRAINT product_qr_codes_product_id_fkey FOREIGN KEY (product_id) REFERENCES docweb.products(id) ON DELETE CASCADE;


--
-- Name: product_qr_codes product_qr_codes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.product_qr_codes
    ADD CONSTRAINT product_qr_codes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: products products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.products
    ADD CONSTRAINT products_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: qr_scans qr_scans_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.qr_scans
    ADD CONSTRAINT qr_scans_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: schema_attributes schema_attributes_schema_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.schema_attributes
    ADD CONSTRAINT schema_attributes_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES docweb.credential_schemas(id) ON DELETE CASCADE;


--
-- Name: schema_attributes schema_attributes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.schema_attributes
    ADD CONSTRAINT schema_attributes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: subscription_plans subscription_plans_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscription_plans
    ADD CONSTRAINT subscription_plans_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: subscriptions subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscriptions
    ADD CONSTRAINT subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES docweb.subscription_plans(id);


--
-- Name: subscriptions subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.subscriptions
    ADD CONSTRAINT subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: system_logs system_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.system_logs
    ADD CONSTRAINT system_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: template_elements template_elements_template_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.template_elements
    ADD CONSTRAINT template_elements_template_id_fkey FOREIGN KEY (template_id) REFERENCES docweb.templates(id) ON DELETE CASCADE;


--
-- Name: template_elements template_elements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.template_elements
    ADD CONSTRAINT template_elements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: templates templates_schema_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.templates
    ADD CONSTRAINT templates_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES docweb.credential_schemas(id);


--
-- Name: templates templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.templates
    ADD CONSTRAINT templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: tenant_settings tenant_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id) ON DELETE CASCADE;


--
-- Name: verification_requests verification_requests_credential_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_requests
    ADD CONSTRAINT verification_requests_credential_id_fkey FOREIGN KEY (credential_id) REFERENCES docweb.credentials(id);


--
-- Name: verification_requests verification_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_requests
    ADD CONSTRAINT verification_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: verification_results verification_results_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_results
    ADD CONSTRAINT verification_results_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: verification_results verification_results_verification_request_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.verification_results
    ADD CONSTRAINT verification_results_verification_request_id_fkey FOREIGN KEY (verification_request_id) REFERENCES docweb.verification_requests(id) ON DELETE CASCADE;


--
-- Name: warranties warranties_owner_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranties
    ADD CONSTRAINT warranties_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: warranties warranties_product_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranties
    ADD CONSTRAINT warranties_product_id_fkey FOREIGN KEY (product_id) REFERENCES docweb.products(id) ON DELETE CASCADE;


--
-- Name: warranties warranties_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranties
    ADD CONSTRAINT warranties_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: warranty_claims warranty_claims_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranty_claims
    ADD CONSTRAINT warranty_claims_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: warranty_claims warranty_claims_warranty_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.warranty_claims
    ADD CONSTRAINT warranty_claims_warranty_id_fkey FOREIGN KEY (warranty_id) REFERENCES docweb.warranties(id) ON DELETE CASCADE;


--
-- Name: webhook_events webhook_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhook_events
    ADD CONSTRAINT webhook_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: webhook_events webhook_events_webhook_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhook_events
    ADD CONSTRAINT webhook_events_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES docweb.webhooks(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: docweb; Owner: -
--

ALTER TABLE ONLY docweb.webhooks
    ADD CONSTRAINT webhooks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: announcements announcements_author_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.announcements
    ADD CONSTRAINT announcements_author_fkey FOREIGN KEY (author_employee_id) REFERENCES hrweb.employees(id);


--
-- Name: announcements announcements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.announcements
    ADD CONSTRAINT announcements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: app_data app_data_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.app_data
    ADD CONSTRAINT app_data_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: articles articles_author_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.articles
    ADD CONSTRAINT articles_author_fkey FOREIGN KEY (author_employee_id) REFERENCES hrweb.employees(id);


--
-- Name: articles articles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.articles
    ADD CONSTRAINT articles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: benefit_enrollments benefit_enrollments_benefit_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.benefit_enrollments
    ADD CONSTRAINT benefit_enrollments_benefit_fkey FOREIGN KEY (benefit_id) REFERENCES hrweb.benefits(id) ON DELETE CASCADE;


--
-- Name: benefit_enrollments benefit_enrollments_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.benefit_enrollments
    ADD CONSTRAINT benefit_enrollments_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: benefit_enrollments benefit_enrollments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.benefit_enrollments
    ADD CONSTRAINT benefit_enrollments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: benefits benefits_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.benefits
    ADD CONSTRAINT benefits_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: company_profile company_profile_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.company_profile
    ADD CONSTRAINT company_profile_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: document_categories document_categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.document_categories
    ADD CONSTRAINT document_categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: documents documents_category_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.documents
    ADD CONSTRAINT documents_category_fkey FOREIGN KEY (category_id) REFERENCES hrweb.document_categories(id);


--
-- Name: documents documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.documents
    ADD CONSTRAINT documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: employee_onboarding employee_onboarding_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: employee_onboarding employee_onboarding_step_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_step_fkey FOREIGN KEY (step_id) REFERENCES hrweb.onboarding_steps(id);


--
-- Name: employee_onboarding employee_onboarding_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employee_onboarding
    ADD CONSTRAINT employee_onboarding_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: employees employees_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: employees employees_user_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.employees
    ADD CONSTRAINT employees_user_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON UPDATE CASCADE;


--
-- Name: events events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.events
    ADD CONSTRAINT events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: generated_documents generated_documents_creator_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.generated_documents
    ADD CONSTRAINT generated_documents_creator_fkey FOREIGN KEY (created_by_employee_id) REFERENCES hrweb.employees(id);


--
-- Name: generated_documents generated_documents_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.generated_documents
    ADD CONSTRAINT generated_documents_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: generated_documents generated_documents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.generated_documents
    ADD CONSTRAINT generated_documents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: integration_webhooks integration_webhooks_creator_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.integration_webhooks
    ADD CONSTRAINT integration_webhooks_creator_fkey FOREIGN KEY (created_by_employee_id) REFERENCES hrweb.employees(id);


--
-- Name: integration_webhooks integration_webhooks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.integration_webhooks
    ADD CONSTRAINT integration_webhooks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: key_task_progress key_task_progress_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_task_progress
    ADD CONSTRAINT key_task_progress_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: key_task_progress key_task_progress_task_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_task_progress
    ADD CONSTRAINT key_task_progress_task_fkey FOREIGN KEY (key_task_id) REFERENCES hrweb.key_tasks(id) ON DELETE CASCADE;


--
-- Name: key_task_progress key_task_progress_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_task_progress
    ADD CONSTRAINT key_task_progress_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: key_tasks key_tasks_assignee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_tasks
    ADD CONSTRAINT key_tasks_assignee_fkey FOREIGN KEY (assignee_employee_id) REFERENCES hrweb.employees(id);


--
-- Name: key_tasks key_tasks_creator_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_tasks
    ADD CONSTRAINT key_tasks_creator_fkey FOREIGN KEY (created_by_employee_id) REFERENCES hrweb.employees(id);


--
-- Name: key_tasks key_tasks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.key_tasks
    ADD CONSTRAINT key_tasks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: notifications notifications_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.notifications
    ADD CONSTRAINT notifications_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: notifications notifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.notifications
    ADD CONSTRAINT notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: onboarding_steps onboarding_steps_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.onboarding_steps
    ADD CONSTRAINT onboarding_steps_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: performance_reviews performance_reviews_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.performance_reviews
    ADD CONSTRAINT performance_reviews_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: performance_reviews performance_reviews_reviewer_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.performance_reviews
    ADD CONSTRAINT performance_reviews_reviewer_fkey FOREIGN KEY (reviewer_employee_id) REFERENCES hrweb.employees(id);


--
-- Name: performance_reviews performance_reviews_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.performance_reviews
    ADD CONSTRAINT performance_reviews_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: report_dashboards report_dashboards_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.report_dashboards
    ADD CONSTRAINT report_dashboards_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: report_dashboards report_dashboards_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.report_dashboards
    ADD CONSTRAINT report_dashboards_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: salary_slips salary_slips_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.salary_slips
    ADD CONSTRAINT salary_slips_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: salary_slips salary_slips_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.salary_slips
    ADD CONSTRAINT salary_slips_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: time_off_balances time_off_balances_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_balances
    ADD CONSTRAINT time_off_balances_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: time_off_balances time_off_balances_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_balances
    ADD CONSTRAINT time_off_balances_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: time_off_requests time_off_requests_approver_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_requests
    ADD CONSTRAINT time_off_requests_approver_fkey FOREIGN KEY (approved_by_employee_id) REFERENCES hrweb.employees(id);


--
-- Name: time_off_requests time_off_requests_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_requests
    ADD CONSTRAINT time_off_requests_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: time_off_requests time_off_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.time_off_requests
    ADD CONSTRAINT time_off_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: training_courses training_courses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.training_courses
    ADD CONSTRAINT training_courses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: training_enrollments training_enrollments_course_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.training_enrollments
    ADD CONSTRAINT training_enrollments_course_fkey FOREIGN KEY (training_course_id) REFERENCES hrweb.training_courses(id) ON DELETE CASCADE;


--
-- Name: training_enrollments training_enrollments_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.training_enrollments
    ADD CONSTRAINT training_enrollments_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: training_enrollments training_enrollments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.training_enrollments
    ADD CONSTRAINT training_enrollments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: user_preferences user_preferences_employee_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.user_preferences
    ADD CONSTRAINT user_preferences_employee_fkey FOREIGN KEY (employee_id) REFERENCES hrweb.employees(id);


--
-- Name: user_preferences user_preferences_tenant_id_fkey; Type: FK CONSTRAINT; Schema: hrweb; Owner: -
--

ALTER TABLE ONLY hrweb.user_preferences
    ADD CONSTRAINT user_preferences_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: app_data app_data_tenant_id_fkey; Type: FK CONSTRAINT; Schema: stayweb; Owner: -
--

ALTER TABLE ONLY stayweb.app_data
    ADD CONSTRAINT app_data_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES core.tenants(id);


--
-- Name: audit_log; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_members members_self_read; Type: POLICY; Schema: core; Owner: -
--

CREATE POLICY members_self_read ON core.tenant_members FOR SELECT TO authenticated USING ((user_id = auth.uid()));


--
-- Name: roles; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.roles ENABLE ROW LEVEL SECURITY;

--
-- Name: roles roles_read; Type: POLICY; Schema: core; Owner: -
--

CREATE POLICY roles_read ON core.roles FOR SELECT TO authenticated USING (true);


--
-- Name: sessions; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_members; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.tenant_members ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants tenants_member_read; Type: POLICY; Schema: core; Owner: -
--

CREATE POLICY tenants_member_read ON core.tenants FOR SELECT TO authenticated USING ((id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: users; Type: ROW SECURITY; Schema: core; Owner: -
--

ALTER TABLE core.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_self_read; Type: POLICY; Schema: core; Owner: -
--

CREATE POLICY users_self_read ON core.users FOR SELECT TO authenticated USING ((id = auth.uid()));


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.activity_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: analytics_events; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.analytics_events ENABLE ROW LEVEL SECURITY;

--
-- Name: api_keys; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: attestations; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.attestations ENABLE ROW LEVEL SECURITY;

--
-- Name: attestations attestations_insert_self; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY attestations_insert_self ON docweb.attestations AS RESTRICTIVE FOR INSERT TO authenticated WITH CHECK ((attested_by_user_id = auth.uid()));


--
-- Name: blockchain_proofs; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.blockchain_proofs ENABLE ROW LEVEL SECURITY;

--
-- Name: blockchain_transactions; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.blockchain_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_attributes; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_attributes ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_history; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_history ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_metrics; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_metrics ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_schemas; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_schemas ENABLE ROW LEVEL SECURITY;

--
-- Name: credential_subjects; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credential_subjects ENABLE ROW LEVEL SECURITY;

--
-- Name: credentials; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: did_entities; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.did_entities ENABLE ROW LEVEL SECURITY;

--
-- Name: did_keys; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.did_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: document_audit_log; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: document_folders; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_folders ENABLE ROW LEVEL SECURITY;

--
-- Name: document_shares; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_shares ENABLE ROW LEVEL SECURITY;

--
-- Name: document_signatures; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_signatures ENABLE ROW LEVEL SECURITY;

--
-- Name: document_signers; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_signers ENABLE ROW LEVEL SECURITY;

--
-- Name: document_stars; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_stars ENABLE ROW LEVEL SECURITY;

--
-- Name: document_stars document_stars_own; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY document_stars_own ON docweb.document_stars AS RESTRICTIVE TO authenticated USING ((user_id = auth.uid())) WITH CHECK ((user_id = auth.uid()));


--
-- Name: document_versions; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.document_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: documents; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.documents ENABLE ROW LEVEL SECURITY;

--
-- Name: integration_events; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.integration_events ENABLE ROW LEVEL SECURITY;

--
-- Name: integrations; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.integrations ENABLE ROW LEVEL SECURITY;

--
-- Name: invoices; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.activity_logs TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: analytics_events members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.analytics_events TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: api_keys members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.api_keys TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: attestations members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.attestations TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: blockchain_proofs members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.blockchain_proofs TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: blockchain_transactions members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.blockchain_transactions TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_attributes members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.credential_attributes TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_history members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.credential_history TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_metrics members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.credential_metrics TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_schemas members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.credential_schemas TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_subjects members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.credential_subjects TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credentials members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.credentials TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: did_entities members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.did_entities TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: did_keys members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.did_keys TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_audit_log members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.document_audit_log TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_folders members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.document_folders TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_shares members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.document_shares TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_signatures members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.document_signatures TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_signers members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.document_signers TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_stars members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.document_stars TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_versions members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.document_versions TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: documents members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.documents TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: integration_events members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.integration_events TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: integrations members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.integrations TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: invoices members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.invoices TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: notifications members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.notifications TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: product_certificates members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.product_certificates TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: product_qr_codes members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.product_qr_codes TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: products members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.products TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: qr_scans members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.qr_scans TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: schema_attributes members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.schema_attributes TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: subscription_plans members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.subscription_plans TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: subscriptions members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.subscriptions TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: system_logs members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.system_logs TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: template_elements members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.template_elements TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: templates members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.templates TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: tenant_settings members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.tenant_settings TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: verification_requests members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.verification_requests TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: verification_results members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.verification_results TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: warranties members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.warranties TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: warranty_claims members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.warranty_claims TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: webhook_events members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.webhook_events TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: webhooks members_access; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY members_access ON docweb.webhooks TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: notifications; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_own_delete; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY notifications_own_delete ON docweb.notifications AS RESTRICTIVE FOR DELETE TO authenticated USING ((user_id = auth.uid()));


--
-- Name: notifications notifications_own_update; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY notifications_own_update ON docweb.notifications AS RESTRICTIVE FOR UPDATE TO authenticated USING ((user_id = auth.uid())) WITH CHECK ((user_id = auth.uid()));


--
-- Name: product_certificates; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.product_certificates ENABLE ROW LEVEL SECURITY;

--
-- Name: product_qr_codes; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.product_qr_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: products; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.products ENABLE ROW LEVEL SECURITY;

--
-- Name: qr_scans; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.qr_scans ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_attributes; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.schema_attributes ENABLE ROW LEVEL SECURITY;

--
-- Name: subscription_plans; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.subscription_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: subscriptions; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: system_logs; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.system_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: template_elements; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.template_elements ENABLE ROW LEVEL SECURITY;

--
-- Name: templates; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.templates ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.activity_logs AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: analytics_events tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.analytics_events AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: api_keys tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.api_keys AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: attestations tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.attestations AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: blockchain_proofs tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.blockchain_proofs AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: blockchain_transactions tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.blockchain_transactions AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_attributes tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_attributes AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_history tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_history AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_metrics tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_metrics AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_schemas tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_schemas AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credential_subjects tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credential_subjects AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: credentials tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.credentials AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: did_entities tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.did_entities AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: did_keys tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.did_keys AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_audit_log tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_audit_log AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_folders tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_folders AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_shares tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_shares AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_signatures tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_signatures AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_signers tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_signers AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_stars tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_stars AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_versions tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.document_versions AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: documents tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.documents AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: integration_events tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.integration_events AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: integrations tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.integrations AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: invoices tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.invoices AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: notifications tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.notifications AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: product_certificates tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.product_certificates AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: product_qr_codes tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.product_qr_codes AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: products tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.products AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: qr_scans tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.qr_scans AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: schema_attributes tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.schema_attributes AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: subscription_plans tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.subscription_plans AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: subscriptions tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.subscriptions AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: system_logs tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.system_logs AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: template_elements tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.template_elements AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: templates tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.templates AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: tenant_settings tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.tenant_settings AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: verification_requests tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.verification_requests AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: verification_results tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.verification_results AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: warranties tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.warranties AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: warranty_claims tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.warranty_claims AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: webhook_events tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.webhook_events AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: webhooks tenant_isolation; Type: POLICY; Schema: docweb; Owner: -
--

CREATE POLICY tenant_isolation ON docweb.webhooks AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: tenant_settings; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.tenant_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: verification_requests; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.verification_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: verification_results; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.verification_results ENABLE ROW LEVEL SECURITY;

--
-- Name: warranties; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.warranties ENABLE ROW LEVEL SECURITY;

--
-- Name: warranty_claims; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.warranty_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: webhook_events; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.webhook_events ENABLE ROW LEVEL SECURITY;

--
-- Name: webhooks; Type: ROW SECURITY; Schema: docweb; Owner: -
--

ALTER TABLE docweb.webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: announcements; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.announcements ENABLE ROW LEVEL SECURITY;

--
-- Name: app_data; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.app_data ENABLE ROW LEVEL SECURITY;

--
-- Name: articles; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.articles ENABLE ROW LEVEL SECURITY;

--
-- Name: benefit_enrollments; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.benefit_enrollments ENABLE ROW LEVEL SECURITY;

--
-- Name: benefits; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.benefits ENABLE ROW LEVEL SECURITY;

--
-- Name: company_profile; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.company_profile ENABLE ROW LEVEL SECURITY;

--
-- Name: document_categories; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.document_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: documents; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.documents ENABLE ROW LEVEL SECURITY;

--
-- Name: employee_onboarding; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.employee_onboarding ENABLE ROW LEVEL SECURITY;

--
-- Name: employees; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.employees ENABLE ROW LEVEL SECURITY;

--
-- Name: events; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.events ENABLE ROW LEVEL SECURITY;

--
-- Name: generated_documents; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.generated_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: integration_webhooks; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.integration_webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: key_task_progress; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.key_task_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: key_tasks; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.key_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: onboarding_steps; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.onboarding_steps ENABLE ROW LEVEL SECURITY;

--
-- Name: performance_reviews; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.performance_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: report_dashboards; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.report_dashboards ENABLE ROW LEVEL SECURITY;

--
-- Name: salary_slips; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.salary_slips ENABLE ROW LEVEL SECURITY;

--
-- Name: announcements tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.announcements AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: app_data tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.app_data AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: articles tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.articles AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: benefit_enrollments tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.benefit_enrollments AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: benefits tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.benefits AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: company_profile tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.company_profile AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: document_categories tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.document_categories AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: documents tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.documents AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: employee_onboarding tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.employee_onboarding AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: employees tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.employees AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: events tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.events AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: generated_documents tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.generated_documents AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: integration_webhooks tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.integration_webhooks AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: key_task_progress tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.key_task_progress AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: key_tasks tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.key_tasks AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: notifications tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.notifications AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: onboarding_steps tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.onboarding_steps AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: performance_reviews tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.performance_reviews AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: report_dashboards tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.report_dashboards AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: salary_slips tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.salary_slips AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: time_off_balances tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.time_off_balances AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: time_off_requests tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.time_off_requests AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: training_courses tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.training_courses AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: training_enrollments tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.training_enrollments AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: user_preferences tenant_isolation; Type: POLICY; Schema: hrweb; Owner: -
--

CREATE POLICY tenant_isolation ON hrweb.user_preferences AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- Name: time_off_balances; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.time_off_balances ENABLE ROW LEVEL SECURITY;

--
-- Name: time_off_requests; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.time_off_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: training_courses; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.training_courses ENABLE ROW LEVEL SECURITY;

--
-- Name: training_enrollments; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.training_enrollments ENABLE ROW LEVEL SECURITY;

--
-- Name: user_preferences; Type: ROW SECURITY; Schema: hrweb; Owner: -
--

ALTER TABLE hrweb.user_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: app_data; Type: ROW SECURITY; Schema: stayweb; Owner: -
--

ALTER TABLE stayweb.app_data ENABLE ROW LEVEL SECURITY;

--
-- Name: app_data tenant_isolation; Type: POLICY; Schema: stayweb; Owner: -
--

CREATE POLICY tenant_isolation ON stayweb.app_data AS RESTRICTIVE TO authenticated USING ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids))) WITH CHECK ((tenant_id IN ( SELECT core.current_tenant_ids() AS current_tenant_ids)));


--
-- PostgreSQL database dump complete
--

\unrestrict gs9LvZfhGcebZaAsGxe26CRVgjotm3BzG3CtgBSt0dAlbSyLEl3jQfUJAHYzWPw

